﻿using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.Inharitances;
using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.System.Logger;
using SitefinityWebApp.Logisz.Core.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SitefinityWebApp.Logisz.Core.System.Plugins;

namespace SitefinityWebApp.Logisz.Core
{
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_CORE_INITIALIZE, 1)]
    public class LogiszPluginBase : ILogiszAutoInitialize
    {

        /// <summary>
        /// List of all registered <see cref="LogiszPlugin"/>s.
        /// </summary>
        private static List<LogiszPlugin> Modules { get; set; }

        /// <summary>
        /// Auto initialize
        /// </summary>
        public void AutoInitialize()
        {
            Modules = new List<LogiszPlugin>();
        }

        /// <summary>
        /// Registers a <see cref="LogiszPlugin"/> so it can be checked, getted and validated. The modules is not added
        /// if it is already existing in the registered modules
        /// </summary>
        public static void RegisterModule(LogiszPlugin module)
        {
            ILogiszLogger logger = LogiszDependencyContainer.Resolve<ILogiszLogger>();
            if (module == null)
            {
                logger.Log("Failed to register an unknown module, it is NULL.");
                return;
            }
            
            if (IsRegistered(module))
            {
                logger.LogException(String.Format("Failed to register module {0}, it is already registered.", module.ModuleName));
                return;
            }

            if (!module.IsValid)
            {
                logger.Log(String.Format("Failed to register module {0} because it is invalid with the following reason: {1}", module.ModuleName, module.GetErrorMessage()));
                return;
            }
            Modules.Add(module);
            logger.Log("Registered logisz module " + module.ModuleName);
        }


        /// <summary>
        /// Checks if a module is registered by it's module name
        /// </summary>
        /// <param name="module">The module we want to check if it is registered</param>
        /// <returns>True if it is registered, false if it is not.</returns>
        public static bool IsRegistered(LogiszPlugin module)
        {
            if (Modules.FirstOrDefault(q => q.ModuleName == module.ModuleName) != null)
                return true;
            return false;
        }

        #region Getters

        /// <summary>
        /// Gets a module by it's name. Returns NULL if the module is not registered
        /// <para>- Finding modules based on name is not case- or white space sensitive</para>
        /// </summary>
        /// <param name="moduleName">Name of the module</param>
        /// <returns><see cref="LogiszPlugin"/> or NULL</returns>
        public static LogiszPlugin GetModule(string moduleName)
        {
            return Modules.FirstOrDefault(q => q.ModuleName.LogiszCompareWith(moduleName));
        }

        /// <summary>
        /// Gets all the registered modules
        /// </summary>
        /// <returns>List of all modules</returns>
        public static List<LogiszPlugin> GetModules()
        {
            return Modules;
        }

        #endregion
    }
}