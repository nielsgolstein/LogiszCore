﻿using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.Events;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using SitefinityWebApp.Logisz.Core.Modules.Debugger;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.System.Plugins.Initialization;

namespace SitefinityWebApp.Logisz.Core
{
    /// <summary>
    /// The core handler of Logisz.
    /// </summary>
    public class LogiszCore
    {
        #region Attributes


        /// <summary>
        /// Private logisz core logger
        /// </summary>
        private readonly ILogiszLogger _logiszLogger;
        private readonly IAutoInitializer _autoInitializer;
        private readonly ILogiszPluginInitializer _pluginInitializer;

        #endregion

        #region Class init

        /// <summary>
        /// Private constructor to keep only ONE instance.
        /// </summary>
        private LogiszCore() {
            LogiszDependencyContainer.RegisterDependencies();

            _autoInitializer = LogiszDependencyContainer.Resolve<IAutoInitializer>();
            _pluginInitializer = LogiszDependencyContainer.Resolve<ILogiszPluginInitializer>();
            _logiszLogger = LogiszDependencyContainer.Resolve<ILogiszLogger>();
            _logiszLogger.InitializeLogger();
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Initializes the Logisz core system.
        /// </summary>
        public void Initialize()
        {

            //Initialize logger
            DateTime initializationStart = DateTime.Now;
            _logiszLogger.Log("Logisz core: Initializing...");


            //Run auto initializer
            _autoInitializer.InitializeCore();
            _pluginInitializer.InitializePlugins();

            DateTime initializationEnd = DateTime.Now;
            DateTime initializationTime = new DateTime((initializationEnd - initializationStart).Ticks);
            _logiszLogger.Log("Logisz core: Finished initialization with a total runtime of: " + initializationTime.ToString("HH:mm:ss:fff"));
        }

        #endregion

        #region Singleton to provide an easy start

        private static LogiszCore instance;
        public static LogiszCore GetInstance()
        {
            instance = instance ?? new LogiszCore();
            return instance;
        }


        #endregion
    }
}