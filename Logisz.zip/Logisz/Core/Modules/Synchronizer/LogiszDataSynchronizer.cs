﻿using Newtonsoft.Json.Linq;
using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.xHttp;
using System;
using System.Web.Script.Serialization;

namespace SitefinityWebApp.Logisz.Core.Modules.Synchronizer
{
    public class LogiszDataSynchronizer : ILogiszDataSynchronizer
    {
        //private readonly ILogiszConfigManager _logiszConfigManager;
        //private LogiszConfig config { get { return _logiszConfigManager.GetConfig(); } }

        /*public LogiszDataSynchronizer(ILogiszConfigManager logiszConfigManager)
        {
            this._logiszConfigManager = logiszConfigManager;
        }*/

        public void Sync()
        {
            //string url = $"{config.Core.CoreModules.Synchronizer.Domain}/api/default/shortcodes";
            string url = "http://codebase2.staging.logisz.com/api/default/shortcodes";

            WebRequestHandler requestHandler = new WebRequestHandler(false);
            string response = String.Empty;
            try
            {
                response = requestHandler.DoGetRequest(url);
            }
            catch (Exception ex) {
                return;
            }

            JObject json = JObject.Parse(response);
            string val = json.GetValue("value").ToString();

            //Perform POST to our domain.
            string ourUrl = "http://codebase2.staging.logisz.com/api/default/shortcodes";
            bool success = requestHandler.DoPostRequest(ourUrl, val);
        }
    }
}