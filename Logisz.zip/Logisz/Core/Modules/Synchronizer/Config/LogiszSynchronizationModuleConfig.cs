﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Modules.Synchronizer.Config
{
    public class LogiszSynchronizationModuleConfig : LogiszCoreModuleConfigElement
    {
        public LogiszSynchronizationModuleConfig(ConfigElement parent) : base(parent) { }

        [ObjectInfo(Title = "Domain url", Description = "Specifies the domain where our date comes from.")]
        [ConfigurationProperty("Domain", DefaultValue = "http://codebase2.staging.logisz.com", IsRequired = true)]
        public bool Domain
        {
            get { return (bool)this["Domain"]; }
            set { this["Domain"] = value; }
        }
    }
}