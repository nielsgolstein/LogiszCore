﻿using IdentityModel.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.Modules.Synchronizer.Token
{
    public static class LogiszRequestTokenProvider
    {
        #region Attributes

        private static TokenClient tokenClient;
        private const string ClientId = "testApp";
        private const string ClientSecret = "secret";
        private const string TokenEndpoint = "/Sitefinity/Authenticate/OpenID/connect/token";
        private const string Username = "niels.golstein@logisz.nl";
        private const string Password = "lgsz!adm1n";
        private const string Scopes = "openid offline_access";
       /* public static readonly Dictionary<string, string> AdditionalParameters = new Dictionary<string, string>()
        {
            { "membershipProvider", "Default" }
        }; */

        #endregion

        /// <summary>
        /// Gets the required SF token to request Web services.
        /// </summary>
        /// <returns></returns>
        public static TokenResponse RequestToken()
        {
            InitTokenClient();
            //This is call to the token endpoint with the parameters that are set
            TokenResponse tokenResponse = tokenClient.RequestResourceOwnerPasswordAsync(Username, Password, Scopes).Result;

            if (tokenResponse.IsError)
            {
                throw new ApplicationException("Couldn't get access token. Error: " + tokenResponse.Error);
            }

            return tokenResponse;
        }

        public static TokenResponse RefreshToken(string refreshToken)
        {
            InitTokenClient();
            //This is call to the token endpoint that can retrieve new access and refresh token from the current refresh token
            return tokenClient.RequestRefreshTokenAsync(refreshToken).Result;
        }

        private static void InitTokenClient()
        {
            string EndPoint = "http://codebase2.staging.logisz.com" + TokenEndpoint;
            tokenClient = tokenClient ?? new TokenClient(EndPoint, ClientId, ClientSecret, AuthenticationStyle.PostValues);
        }
    }
}