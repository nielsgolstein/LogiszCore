﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SitefinityWebApp.Logisz.Core.Modules.Synchronizer
{
    public interface ILogiszDataSynchronizer
    {
        void Sync();
    }
}
