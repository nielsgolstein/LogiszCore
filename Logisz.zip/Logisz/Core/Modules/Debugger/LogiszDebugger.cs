﻿using System.Linq;
using System.Collections.Generic;
using System.Web;
using System;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.Modules.Debugger.Models;
using System.Reflection;
using SitefinityWebApp.Logisz.Core.Inharitances;
using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.System.Logger;
using SitefinityWebApp.Logisz.Core.Utilities;
using SitefinityWebApp.Logisz.Core.System;
using SitefinityWebApp.Logisz.Core.System.Plugins;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger
{
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_CORE_INITIALIZE)]
    public sealed class LogiszDebugger : ILogiszDebugger, ILogiszAutoInitialize
    {
        #region Attributes

        private string SessionName { get; set; }
        private readonly ILogiszUserManager _logiszUserManager;
        private readonly ILogiszConfigManager _logiszConfigManager;
        private readonly ILogiszLogger _logiszLogger;
        private LogiszConfig config { get; set; }

        #endregion

        #region Constructor

        private LogiszDebugger(ILogiszUserManager logiszUserManager,
            ILogiszLogger logiszLogger,
            ILogiszConfigManager logiszConfigManager)
        {
            this._logiszUserManager = logiszUserManager;
            this._logiszConfigManager = logiszConfigManager;
            this._logiszLogger = logiszLogger;
        }

        public void AutoInitialize()
        {
            this.config = _logiszConfigManager.GetConfig();
            this.SessionName = config.Core.CoreModules.Debugger.SessionName;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the debug results
        /// </summary>
        /// <returns>LogiszDebugResults</returns>
        public LogiszDebugResults GetResults()
        {
            RegisterDefaultCoreModules();
            
            LogiszDebugResults results = HttpContext.Current.Session[SessionName] as LogiszDebugResults;
            results = RemoveInactiveModules(results);
            //If there are NO results, we fill it with empty result.
            //results = new LogiszDebugResults(results);
            //results = RemoveInactiveModules(results);

            return results;
        }


        /// <summary>
        /// Stores the debug data of an unknown type.
        /// </summary>
        /// <typeparam name="T">The data type</typeparam>
        /// <param name="moduleName">Name of the module</param>
        /// <param name="viewName">Viewname</param>
        /// <param name="viewPath">Pathname</param>
        /// <param name="data">The data object</param>
        public void TryEnableDebugger<T>(string moduleName, string viewName, string viewPath, T data)
        {
            //If debug is disabled, we dont store data.
            if (!ValidateDebugActivity(moduleName))
                return;


            //Check if we are using the default view or not
            string viewLoc = String.Format("{0}{1}.cshtml", viewPath, viewName);


            ILogiszDebug debug = new LogiszModuleDebugViewModel(
                viewLoc, moduleName, null
            );

            debug.Data = BreakObjectToPieces<T>(data);
            debug.DataType = typeof(T);
            StoreCustomDebugData(debug);
        }


        /// <summary>
        /// Stores the debug data of a <see cref="LogiszPlugin"/>, but only when the debug is active for this module.
        /// Only works with a custom T object and a custom view.
        /// </summary>
        /// <typeparam name="T">Datatype of the to store object</typeparam>
        /// <param name="module">The module which is debugging</param>
        /// <param name="data">The actual data object</param>
        public void TryEnableDebugger<T>(LogiszPlugin module, T data)
        {
            //If debug is disabled, we dont store data.
            if (!ValidateDebugActivity(module.ModuleName, module.Config))
                return;

            if (!LogiszPluginBase.IsRegistered(module))
            {
                RemoveDataModule(module.ModuleName);
                return;
            }
                

            //Check if we are using the default view or not
            string viewName = String.Format("{0}{1}/{2}.cshtml", module.ModulePath, module.ModuleName, module.Config.DebugViewName);
            bool isDefaultView = config.Core.CoreModules.Debugger.DefaultOutputViewName == module.Config.DebugViewName;

            //Check for default
            if(isDefaultView)
            {
                viewName = String.Format("{0}{1}.cshtml", config.Core.CoreModules.Debugger.DefaultOutputViewPath, module.Config.DebugViewName);
            }

            string name = String.IsNullOrEmpty(module.FriendlyModuleName) ? module.ModuleName : module.FriendlyModuleName;
            ILogiszDebug debug = new LogiszModuleDebugViewModel(
                viewName, name, module.Config
            );

            //If this is the default view, we break the object
            if (isDefaultView)
            {
                debug.SetDataObject<Dictionary<string, dynamic>>(BreakObjectToPieces<T>(data));
            }
            else
            {
                debug.SetDataObject<T>(data);
            }

            StoreCustomDebugData(debug);
        }


        /// <summary>
        /// Stores the debug data of a <see cref="LogiszPlugin"/>, but only when the debug is active for this module.
        /// </summary>
        /// <param name="moduleName">The name of the module</param>
        /// <param name="config">The config the module is using (<see cref="LogiszConfigElement"/>)</param>
        /// <returns>True | False if the debugger data is set or not.</returns>
        public bool TryEnableDebugger(string moduleName, LogiszModuleConfigElement config)
        {
            //If debug is disabled, we dont store data.
            if (!ValidateDebugActivity(moduleName, config))
                return false;

            StoreDebugDataWithProps(moduleName, DebugData, config);

            //Reset debug data.
            DebugData = new Dictionary<string, string>();

            return true;
        }


        /// <summary>
        /// Creates a new LogiszDebug item
        /// </summary>
        /// <param name="config">Configuration</param>
        /// <param name="viewName">The name</param>
        /// <param name="data">The data object</param>
        public void RegisterCoreModule(string viewName, string friendlyName, object data, LogiszConfig config = null)
        {
            config = config ?? _logiszConfigManager.GetConfig();

            ILogiszDebug debug = new LogiszCoreDebugViewModel(
                config.Core.CoreModules.Debugger.DefaultOutputViewPath + "LogiszCore/" + viewName + ".cshtml", 
                friendlyName, 
                null);
            debug.Data = data;

            if (data != null)
                debug.DataType = data.GetType();

            StoreCustomDebugData(debug);
        }

        /// <summary>
        /// Simply debug
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataObject"></param>
        public void QuickDebug<T>(T dataObject)
        {
            TryEnableDebugger(Constants.QUICK_DEBUG_FRIENDLYNAME, Constants.QUICK_DEBUG_VIEWNAME, Constants.QUICK_DEBUG_VIEWPATH, dataObject);
        }

        /// <summary>
        /// Adds a data layer to the debugger for a specific module
        /// </summary>
        /// <param name="key">Key value</param>
        /// <param name="value">Result value</param>
        public void AddDebugData(string key, string value)
        {
            if(!DebugData.ContainsKey(key))
                DebugData.Add(key, value);
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Store the <see cref="LogiszDebug"/> object in the session
        /// </summary>
        /// <param name="data">Debug data object</param>
        private void StoreCustomDebugData(ILogiszDebug data)
        {
            UpdateDataModule(data);
        }

        private Dictionary<string, string> DebugData = new Dictionary<string, string>();


        /// <summary>
        /// Store the <see cref="LogiszDebug"/> object in the session
        /// </summary>
        /// <param name="data">Debug data object</param>
        private void UpdateDataModule(ILogiszDebug module)
        {
            LogiszDebugResults currentStoredResults = GetStoredData();

            //Remove if same module
            if (currentStoredResults.modules.Select(x => x.Title).Contains(module.Title))
            {
                currentStoredResults.modules.Remove(
                    currentStoredResults.modules.First(x => x.Title == module.Title)
                );
            }

            //Re-add it.
            currentStoredResults.modules.Add(module);

            //Set active
            currentStoredResults.hasActiveModules = true;

            UpdateDataSession(currentStoredResults);
        }

        /// <summary>
        /// Remove the <see cref="LogiszDebug"/> object from the session
        /// </summary>
        /// <param name="data">Debug data object</param>
        private void RemoveDataModule(string moduleName)
        {
            LogiszDebugResults currentStoredResults = GetStoredData();

            //Remove if same module
            if (currentStoredResults.modules.Select(x => x.Title).Contains(moduleName))
            {
                currentStoredResults.modules.Remove(
                    currentStoredResults.modules.First(x => x.Title == moduleName)
                );
            }

            //Set active
            if(currentStoredResults.GetDebugViewsOfType<LogiszModuleDebugViewModel>().Count > 0)
                currentStoredResults.hasActiveModules = true;

            UpdateDataSession(currentStoredResults);

            DebugData.Clear();
        }

        /// <summary>
        /// Simply updates the session
        /// </summary>
        /// <param name="newRes">New data</param>
        private void UpdateDataSession(LogiszDebugResults newRes)
        {
            HttpContext.Current.Session[SessionName] = newRes;
        }


        /// <summary>
        /// Stores the debug data to the session
        /// </summary>
        /// <param name="name">Module name</param>
        /// <param name="data">Data</param>
        /// <param name="moduleConfig">Config of the module</param>
        /// <param name="View">Viewname</param>
        private void StoreDebugDataWithProps(string name, Dictionary<string, string> data, LogiszModuleConfigElement moduleConfig, string View = null)
        {
            //Get module
            View = View ?? config.Core.CoreModules.Debugger.DefaultOutputViewPath + config.Core.CoreModules.Debugger.DefaultOutputViewName + ".cshtml";
            ILogiszDebug module = new LogiszModuleDebugViewModel(View, name, moduleConfig);

            Dictionary<string, dynamic> Properties = new Dictionary<string, dynamic>();
            //Prop is property of THIS class (LogiszDebugResults)
            foreach (KeyValuePair<string, string> prop in data)
            {
                //Add the property to our Module model.
                Properties.Add(prop.Key.ToString(), prop.Value);
            }

            module.SetDataObject<Dictionary<string, dynamic>>(Properties);

            UpdateDataModule(module);
        }


        /// <summary>
        /// Gets already stored data
        /// </summary>
        /// <returns></returns>
        private LogiszDebugResults GetStoredData()
        {
            LogiszDebugResults data = HttpContext.Current.Session[SessionName] as LogiszDebugResults;

            //If NULL, create one.
            if (data == null)
                data = new LogiszDebugResults(null);

            return data;
        }


        /// <summary>
        /// Breaks an object into readable pieces using a <see cref="Dictionary<>"/>
        /// </summary>
        /// <typeparam name="T">The object type</typeparam>
        /// <param name="dataObject">The object to break</param>
        /// <returns>Dictionary<string, dynamic></returns>
        private Dictionary<string, dynamic> BreakObjectToPieces<T>(T dataObject)
        {
            //Check type
            Type contentType = typeof(T);

            Dictionary<string, dynamic> results = new Dictionary<string, dynamic>();
            //Prop is property of THIS class (LogiszDebugResults)
            foreach (PropertyInfo prop in contentType.GetProperties())
            {
                Type propType = prop.PropertyType;
                if (propType != typeof(string)
                    && propType != typeof(int)
                    && propType != typeof(decimal)
                    && propType != typeof(double)
                    && propType != typeof(bool))
                    continue;

                //Add the property to our Module model.
                results.Add(prop.Name, prop.GetValue(dataObject));
            }

            return results;
        }


        /// <summary>
        /// Removes inactive modules and saves it into the session data
        /// </summary>
        /// <param name="res">Results</param>
        /// <returns>LogiszDebugResults</returns>
        private LogiszDebugResults RemoveInactiveModules(LogiszDebugResults res)
        {
            List<ILogiszDebug> modules = res.modules;

            //Filter inactives
            res.modules = res.modules.Where(q =>
                q.IsInDebugMode()
            ).ToList();

            if (res.modules.Count == 0)
            { res.hasActiveModules = false; }
            else
            { res.modules.First().CssClass += "active"; }

            UpdateDataSession(res);

            return res;
        }

        /// <summary>
        /// Check if we need to debug or that we are going to abort it.
        /// </summary>
        /// <param name="moduleName">Name of the module</param>
        /// <param name="config">Config of the module</param>
        /// <returns>True if we can enable debug, also true if the config is NULL</returns>
        private bool ValidateDebugActivity(string moduleName, LogiszModuleConfigElement config)
        {
            if (config == null)
                return true;

            ///Check if the debug is true and if the moduleName is valid.
            if (!config.Debug || !ValidateDebugActivity(moduleName))
            {
                RemoveDataModule(moduleName);
                return false;
            }

            return true;
        }


        /// <summary>
        /// Check if we need to debug or that we are going to abort it.
        /// </summary>
        /// <param name="moduleName">Name of the module</param>
        /// <param name="config">Config of the module</param>
        /// <returns>True if we can enable debug, also true if the config is NULL</returns>
        private bool ValidateDebugActivity(string moduleName)
        {
            if (config == null)
                return true;

            if (!_logiszUserManager.GetLoggedOnUser().IsDeveloper)
            {
                RemoveDataModule(moduleName);
                return false;
            }

            return true;
        }


        /// <summary>
        /// Registers default modules
        /// </summary>
        private void RegisterDefaultCoreModules()
        {
            ///Init permissions
            RegisterCoreModule("Main", "Main",
                null
                );

            ///Register logs
            foreach (Log log in _logiszLogger.GetLogs())
            {
                RegisterCoreModule("Log", log.FriendlyName, log);
            }

        }

        #endregion
    }
}