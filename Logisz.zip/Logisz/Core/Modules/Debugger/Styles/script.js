﻿
var finished = false;
var resultView;
var debuggerId = "LogiszDebugger";
var toggleAttribute = "data-outputtoggle";
var moduleOutputClassname = "moduleOutput";
var moduleOutputAttribute = "data-module";
var classToHide = "hidden";
var menuId = "LogiszDebugMenu";
var coreMenuId = "LogiszTopMenu";
var collapsedClass = "collapsed";
var reqUrl;
/*
    * Prepare a request to receive debug data
    */
function PrepareRequest(url) {
    this.reqUrl = url;
    setTimeout(function () {
        //AJAX Call to get debug data
        resultView = $("[data-function='output']");
        Request(reqUrl);

        //if (!finished) {
        //    PrepareRequest();
        //}

    }, 500);
}



/**
    * Request to update debug data
    */
function Request(url) {

    $.ajax({
        method: "GET",
        url: url
    })
        .done(function (response) {

            var responseAsHtml = $(response);
            if (responseAsHtml == null || responseAsHtml == "") {
                console.log("Empty response");
                return;
            }

            var debugData = $('#LogiszDebugResult', responseAsHtml);
            if (debugData != null && debugData.length != 0) {
                finished = true;
                resultView.html(debugData);

                toggle();
            } else {
                resultView.find(".loader").addClass("froze");
            }
        }
        );
}

///Event on menu click
function toggle(dataModule) {

    var allOutputFields = document.getElementsByClassName(moduleOutputClassname)

    //Add and remove from output
    for (var i = 0; i < allOutputFields.length; i++) {
        var outputFieldToHide = allOutputFields[i];
        if (dataModule == null && i == 0) {
            continue;
        } else if (dataModule == outputFieldToHide.attributes.getNamedItem(moduleOutputAttribute).value) {
            outputFieldToHide.classList.remove(classToHide);
            continue;
        }

        outputFieldToHide.classList.add(classToHide);
    }

    //Remove ACTIVE from news item.
    var menu = document.getElementById(menuId);
    var coreMenu = document.getElementById(coreMenuId);
    var coreMenuItems = coreMenu.getElementsByTagName("li");
    var menuItems = menu.getElementsByTagName("li");

    for (var i = 0; i < menuItems.length + coreMenuItems.length; i++) {

        var item = null;
        if (i > menuItems.length-1) {
            item = coreMenuItems[i - menuItems.length];
        } else {
            item = menuItems[i];
        }

        if (item.classList.contains("active")) {
            item.classList.remove("active");
        }

        if (item.attributes.getNamedItem(toggleAttribute).value == dataModule || (dataModule == null && i == 0)) {
            item.classList.add("active");
        }
    }
}


function toggledebugger() {

    var db = document.getElementById(debuggerId);

    if (db.classList.contains(collapsedClass)) {
        db.classList.remove(collapsedClass);
    } else {
        db.classList.add(collapsedClass);
    }

}
