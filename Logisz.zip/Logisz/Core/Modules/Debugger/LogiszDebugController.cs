﻿
using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using SitefinityWebApp.Logisz.Core.Inharitances;
using SitefinityWebApp.Logisz.Core.Modules.Debugger.Models;
using System.Web.Mvc;
using Telerik.Sitefinity.Mvc;
using Telerik.Sitefinity.Services;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger
{
    [ControllerToolboxItem(Name = "LogiszDebugger", Title = "Logisz debugger", SectionName = "Logisz Core")]
    public class LogiszDebugController : Controller
    {

        #region Attributes

        private readonly ILogiszUserManager _logiszUserManager;
        private readonly ILogiszConfigManager _logiszConfigManager;
        private readonly ILogiszDebugger _logiszDebugger;
        private LogiszConfig config { get; set; }

        #endregion

        #region Constructor

        public LogiszDebugController()
        {
            this._logiszUserManager = LogiszDependencyContainer.Resolve<ILogiszUserManager>();
            this._logiszConfigManager = LogiszDependencyContainer.Resolve<ILogiszConfigManager>();
            this._logiszDebugger = LogiszDependencyContainer.Resolve<ILogiszDebugger>();
            this.config = _logiszConfigManager.GetConfig();
        }

        #endregion


        /// <summary>
        /// Return loader view
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            //Validate designermode
            if (SystemManager.IsDesignMode || SystemManager.IsPreviewMode)
                return null;

            if (!_logiszUserManager.GetLoggedOnUser().IsDeveloper)
                return null;

            //Get default results. if empty. it contains core modules
            LogiszDebugResults results = _logiszDebugger.GetResults();

            if (!config.Core.CoreModules.Debugger.AlwaysVisible)
            {
                if (results.modules.Count == 0)
                    return null;
            }

            //If there are no modules debugging... the debugger is collapsed.
            if (results.modules.Count == 0)
                results.collapsed = true;

            return View(config.Core.CoreModules.Debugger.DefaultOutputViewPath + "DebugLoader.cshtml", results);
        }

        /// <summary>
        /// Load debug data
        /// </summary>
        /// <returns>ActionResult | View</returns>
        public ActionResult LoadData()
        {
            //Validate role
            if (!_logiszUserManager.GetLoggedOnUser().IsDeveloper)
                return null;

            LogiszDebugResults results = _logiszDebugger.GetResults();

            return View(config.Core.CoreModules.Debugger.DefaultOutputViewPath + "Debug.cshtml", results);
        }


    }
}