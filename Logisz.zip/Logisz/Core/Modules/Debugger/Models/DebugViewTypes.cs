﻿namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    /// <summary>
    /// Diffirent types of debug views
    /// </summary>
    public enum DebugViewTypes
    {
        MODULE, COREMODULE
    }
}