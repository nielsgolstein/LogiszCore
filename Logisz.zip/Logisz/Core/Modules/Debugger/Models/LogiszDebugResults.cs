﻿using System.Collections.Generic;
using System.Linq;
using SitefinityWebApp.Logisz.Core.System.Dependency;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    /// <summary>
    /// Logisz debug results model, containing all modules and menu items.
    /// </summary>
    public class LogiszDebugResults
    {
        public bool hasActiveModules { get; set; }

        /// <summary>
        /// Indicates if the debugger is collapsed or not. Is only filled after initialize
        /// </summary>
        public bool collapsed { get;  set; }

        /// <summary>
        /// The debug modules
        /// </summary>
        public List<ILogiszDebug> modules { get; set; }


        /// <summary>
        /// Core modules
        /// </summary>
        //public LogiszCoreModules coreModules { get; set; }
        //public List<ILogiszDebug> coreModules { get; private set; }

        /// <summary>
        /// Creates new results, remains the modules of the old result
        /// </summary>
        /// <param name="existingResults"></param>
        public LogiszDebugResults(LogiszDebugResults existingResults)
        {
            ILogiszDebugger _logiszDebugger = LogiszDependencyContainer.Resolve<ILogiszDebugger>();

            if (existingResults == null)
            {
                modules = new List<ILogiszDebug>();
                hasActiveModules = false;
            }
            else
            {
                modules = existingResults.modules;
                hasActiveModules = existingResults.hasActiveModules;
            }
        }


        /// <summary>
        /// Gets all modules of a specific type.
        /// </summary>
        /// <typeparam name="TType">The type</typeparam>
        /// <returns>List of modules or an empty list.</returns>
        public List<TType> GetDebugViewsOfType<TType>()
        {
            return modules.Where(m => m.BaseClass == typeof(TType)).Select(q => (TType)q).ToList();
        }

    }
}