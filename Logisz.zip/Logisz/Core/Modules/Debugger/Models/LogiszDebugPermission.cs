﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Debugger;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using SitefinityWebApp.Logisz.Core.Extensions.Security.Models;
using System.Collections.Generic;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    public class LogiszDebugPermission
    {
        public List<LogiszUser> developers { get; set; }
        public LogiszDebuggerModuleConfig config { get; private set; }
        private LogiszUserManager logiszUserManager { get; set; }

        public LogiszDebugPermission(LogiszDebuggerModuleConfig config)
        {
            this.config = config;
            this.logiszUserManager = LogiszUserManager.GetManager();
            Initialize();
        }

        /// <summary>
        /// Initialize model on creating
        /// </summary>
        private void Initialize()
        {
            developers = logiszUserManager.GetDevelopers();
        }

    }
}