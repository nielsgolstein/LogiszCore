﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    public class LogiszCoreDebugViewModel : ILogiszDebug
    {
        public string View { get; set; }
        public string Title { get; set; }
        public dynamic Data { get; set; }
        public Type DataType { get; set; }
        public string CssClass { get; set; }
        public LogiszModuleConfigElement DebugConfig { get; private set; }
        public Type BaseClass { get; set; }


        /// <summary>
        /// A normal view model
        /// </summary>
        /// <param name="view"></param>
        /// <param name="title"></param>
        /// <param name="config"></param>
        public LogiszCoreDebugViewModel(string view, string title, LogiszModuleConfigElement config)
        {
            this.View = view;
            this.Title = title;
            this.DebugConfig = config;
            this.BaseClass = typeof(LogiszCoreDebugViewModel);
        }

        /// <summary>
        /// Sets the data of this debug element
        /// </summary>
        /// <typeparam name="T">Type of the data</typeparam>
        /// <param name="data">The data</param>
        public void SetDataObject<T>(T data)
        {
            this.Data = data;
            this.DataType = typeof(T);
        }


        /// <summary>
        /// Indicates if this module is in debug mode
        /// </summary>
        /// <returns></returns>
        public bool IsInDebugMode()
        {
            return true;
        }
    }
}