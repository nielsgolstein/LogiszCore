﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    public interface ILogiszDebug
    {
        string View { get; set; }
        string Title { get; set; }
        dynamic Data { get; set; }
        Type DataType { get; set; }
        string CssClass { get; set; }
        LogiszModuleConfigElement DebugConfig { get; }
        Type BaseClass { get; set; }

        /// <summary>
        /// Returns true if this debug element is active or not.
        /// </summary>
        /// <returns></returns>
        bool IsInDebugMode();

        void SetDataObject<T>(T data);
    }
}
