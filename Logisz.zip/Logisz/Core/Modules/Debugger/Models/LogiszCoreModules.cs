﻿using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.Modules.Logger;
using SitefinityWebApp.Logisz.Core.Tasks.Scheduler;
using System.Collections.Generic;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    public class LogiszCoreModules
    {
        
        /// <summary>
        /// All modules
        /// </summary>
        public List<ILogiszDebug> modules { get; private set; }

        /// <summary>
        /// Auto init properties
        /// </summary>
        public LogiszCoreModules()
        {
            modules = new List<LogiszDebug>();

            LogiszConfig config = LogiszConfigManager.GetConfig();
        }

        ///// <summary>
        ///// Creates a new LogiszDebug item
        ///// </summary>
        ///// <param name="config">Configuration</param>
        ///// <param name="name">The name</param>
        ///// <param name="data">The data object</param>
        ///// <returns></returns>
        //private LogiszDebug CreateDebugElement(LogiszConfig config, string name, string friendlyName, object data)
        //{
        //    LogiszDebug debug = new LogiszDebug(config.Core.CoreModules.Debugger.DefaultOutputViewPath + "LogiszCore/" + name + ".cshtml", friendlyName, null);
        //    debug.Data = data;
        //    debug.DataType = data.GetType();

        //    return debug;
        //}

    }
}