﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger.Models
{
    /// <summary>
    /// Logisz debug model, holding debug data about a module
    /// </summary>
    public abstract class LogiszDebug
    {
        public string View { get; set; }
        public string Title { get; set; }
        public dynamic Data { get; set; }
        public Type DataType { get; set; }
        public string CssClass { get; set; }
        public LogiszModuleConfigElement DebugConfig { get; private set; }

        /// <summary>
        /// The debug element
        /// </summary>
        /// <param name="view">The full view path</param>
        /// <param name="title">The title of the model data</param>
        public LogiszDebug(string view, string title, LogiszModuleConfigElement config)
        {
            this.Title = title;
            this.View = view;
            this.DebugConfig = config;
        }

        /// <summary>
        /// Gets the data as T
        /// </summary>
        /// <typeparam name="T">Type of data</typeparam>
        /// <returns><see cref="T"/></returns>
        public T GetData<T>()
        {
            return (T)Data;
        }
    }
}