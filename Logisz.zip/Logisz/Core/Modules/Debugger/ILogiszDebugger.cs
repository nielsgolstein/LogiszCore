﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.Inharitances;
using SitefinityWebApp.Logisz.Core.Modules.Debugger.Models;
using SitefinityWebApp.Logisz.Core.System.Plugins;
using System.Collections.Generic;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger
{
    public interface ILogiszDebugger
    {


        /// <summary>
        /// Gets the debug results
        /// </summary>
        /// <returns>LogiszDebugResults</returns>
        LogiszDebugResults GetResults();


        /// <summary>
        /// Stores the debug data of a <see cref="LogiszPlugin"/>, but only when the debug is active for this module.
        /// Only works with a custom T object and a custom view.
        /// </summary>
        /// <typeparam name="T">Datatype of the to store object</typeparam>
        /// <param name="moduleName">The module name</param>
        /// <param name="config">The used <see cref="LogiszModuleConfigElement"/></param>
        /// <param name="data">The actual data object</param>
        void TryEnableDebugger<T>(string moduleName, string viewName, string viewPath, T data);


        /// <summary>
        /// Stores the debug data of a <see cref="LogiszPlugin"/>, but only when the debug is active for this module.
        /// Only works with a custom T object and a custom view.
        /// </summary>
        /// <typeparam name="T">Datatype of the to store object</typeparam>
        /// <param name="module">The module which is debugging</param>
        /// <param name="data">The actual data object</param>
        void TryEnableDebugger<T>(LogiszPlugin module, T data);



        /// <summary>
        /// Stores the debug data of a <see cref="LogiszPlugin"/>, but only when the debug is active for this module.
        /// </summary>
        /// <param name="moduleName">The name of the module</param>
        /// <param name="config">The config the module is using (<see cref="LogiszConfigElement"/>)</param>
        /// <returns>True | False if the debugger data is set or not.</returns>
        bool TryEnableDebugger(string moduleName, LogiszModuleConfigElement config);

        /// <summary>
        /// Enable easy debugging
        /// </summary>
        /// <typeparam name="T">Object type</typeparam>
        /// <param name="dataObject">The object</param>
        void QuickDebug<T>(T dataObject);

        /// <summary>
        /// Adds a data layer to the debugger for a specific module
        /// </summary>
        /// <param name="key">Key value</param>
        /// <param name="value">Result value</param>
        void AddDebugData(string key, string value);


        /// <summary>
        /// Creates a new LogiszDebug item
        /// </summary>
        /// <param name="config">Configuration</param>
        /// <param name="viewName">The name</param>
        /// <param name="data">The data object</param>
        void RegisterCoreModule(string viewName, string friendlyName, object data, LogiszConfig config = null);
    }
}