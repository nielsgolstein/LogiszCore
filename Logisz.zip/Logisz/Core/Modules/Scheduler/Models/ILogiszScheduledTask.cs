﻿using SitefinityWebApp.Logisz.Core.Modules.Logger;

namespace SitefinityWebApp.Logisz.Core.Tasks.Scheduler
{
    public interface ILogiszScheduledTask
    {
        int RescheduleEveryXSeconds { get; }
        bool doReschedule { get; }
        LogiszLogger logger { get; }
        void Reschedule();
    }
}