﻿using SitefinityWebApp.Logisz.Core.Extensions;
using SitefinityWebApp.Logisz.Core.Modules.AutoInitializer;
using SitefinityWebApp.Logisz.Core.Modules.Debugger;
using SitefinityWebApp.Logisz.Core.Modules.Logger;
using SitefinityWebApp.Logisz.Core.Modules.Scheduler.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Data;
using Telerik.Sitefinity.Scheduling;
using Telerik.Sitefinity.Scheduling.Model;

namespace SitefinityWebApp.Logisz.Core.Tasks.Scheduler
{
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_BEFORE_CORE_INITIALIZE)]
    public class LogiszScheduledTaskManager : ILogiszAutoInitialize
    {
        private SchedulingManager schedulingManager { get; set; }
        private readonly string transitionName = "scheduleTrans";
        public static readonly string LOGISZ_TASK_PREFIX = "LogiszTask_";
        private LogiszLogger logger { get { return LogiszLogger.Get(); } }

        /// <summary>
        /// Private constructor for singleton instance.
        /// </summary>
        private LogiszScheduledTaskManager()
        {
            schedulingManager = SchedulingManager.GetManager(String.Empty, transitionName);
            schedulingManager.Provider.SuppressSecurityChecks = true;
        }


        /// <summary>
        /// Auto initialize
        /// </summary>
        public void AutoInitialize()
        {
            //Register log
            logger.RegisterLog("Tasks", "Tasks");

            try
            {
                 RegisterTask(new LogiszSiteTriggerTask()
                 {
                     ExecuteTime = DateTime.UtcNow.AddSeconds(120),
                     Key = "SiteTrigger"
                 });

            } catch(LogiszTaskRegistrationFailedException ex)
            {

            }

            ///Register module
            LogiszDebugger.Get().RegisterCoreModule("ScheduledTasks", "Tasks",
                LogiszScheduledTaskManager.GetManager().GetRegisteredTasks()
            );
        }


        /// <summary>
        /// Registers a scheduled task
        /// </summary>
        /// <typeparam name="T">The task object type</typeparam>
        /// <param name="newTask">The task object</param>
        public void RegisterTask<T>(T newTask) where T : ScheduledTask
        {
            ///If key is empty, return.
            if (String.IsNullOrEmpty(newTask.Key))
                throw new LogiszTaskRegistrationFailedException("LogiszScheduledTaskManager: Failed to create task due it's empty key");

            //Check if task exist | Delete if exist
            ScheduledTaskData task = GetTask(newTask.Key);
            if(task != null)
            {
                schedulingManager.DeleteTaskData(task);
                TransactionManager.CommitTransaction(transitionName);
            }
            
            schedulingManager.AddTask(newTask);

            SchedulingManager.RescheduleNextRun();
            TransactionManager.CommitTransaction(transitionName);
            logger.Log("LogiszScheduledTaskManager: Registered scheduled task " + newTask.Key, "Tasks");
        }


        /// <summary>
        /// Gets all scheduled tasks
        /// </summary>
        /// <returns></returns>
        public List<ScheduledTaskData> GetRegisteredTasks()
        {
            return schedulingManager.GetTaskData().ToList();
        }


        /// <summary>
        /// Get existing task by key
        /// </summary>
        /// <param name="key">The key</param>
        /// <returns>ScheduledTaskData</returns>
        private ScheduledTaskData GetTask(string key)
        {
            return schedulingManager.GetTaskData().FirstOrDefault(x => x.Key == key);
        }


        #region Singleton

        private static LogiszScheduledTaskManager instance;
        public static LogiszScheduledTaskManager GetManager()
        {
            instance = instance ?? new LogiszScheduledTaskManager();
            return instance;
        }

        #endregion
    }
}