﻿using SitefinityWebApp.Logisz.Core.Modules.Logger;
using SitefinityWebApp.Logisz.Core.Tasks.Scheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Scheduling;

namespace SitefinityWebApp.Logisz.Core.Modules.Scheduler.Tasks
{
    public class LogiszSiteTriggerTask : ScheduledTask, ILogiszScheduledTask
    {
        public LogiszLogger logger { get { return LogiszLogger.Get(); } }

        /// <summary>
        /// Indicates the time this task is executed
        /// </summary>
        public int RescheduleEveryXSeconds { get; private set; }

        /// <summary>
        /// Indicates if we do a re-schedule
        /// </summary>
        public bool doReschedule { get; private set; }


        public LogiszSiteTriggerTask() {
            this.RescheduleEveryXSeconds = 180;
            doReschedule = this.RescheduleEveryXSeconds != 0;
        }

        /// <summary>
        /// Execute task
        /// </summary>
        public override void ExecuteTask()
        {
            
            logger.Log("Started executing task" + Key, "Tasks");

            //Reschedule
            Reschedule();
        }

        /// <summary>
        /// Reschedule the task
        /// </summary>
        public void Reschedule()
        {
            logger.Log("Finished executing task " + Key, "Tasks");
            DateTime finishedAt = DateTime.UtcNow;

            if(doReschedule)
            {
                DateTime rescheduleTime = DateTime.UtcNow.AddSeconds(RescheduleEveryXSeconds);
                logger.Log("Task " + Key + " is rescheduled at " + rescheduleTime.ToLocalTime(), "Tasks");

                //Reschedule the task.
                LogiszScheduledTaskManager.GetManager().RegisterTask(new LogiszSiteTriggerTask()
                {
                    ExecuteTime = rescheduleTime,
                    Key = LogiszScheduledTaskManager.LOGISZ_TASK_PREFIX + "SiteTrigger"
                });
            }
            
        }
    }
}