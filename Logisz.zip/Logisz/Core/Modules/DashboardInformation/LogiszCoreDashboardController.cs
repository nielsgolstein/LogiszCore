﻿
using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using System.Web.Mvc;
using Telerik.Sitefinity.Mvc;

namespace SitefinityWebApp.Logisz.Core.Modules.Debugger
{
    [ControllerToolboxItem(Name = "LogiszDashboard", Title = "Logisz dashboard", SectionName = "Logisz Core")]
    public class LogiszCoreDashboardController : Controller
    {
        private readonly ILogiszUserManager _logiszUserManager;
        private readonly ILogiszConfigManager _logiszConfigManager;

        public LogiszCoreDashboardController()
        {
            this._logiszUserManager = LogiszDependencyContainer.Resolve<ILogiszUserManager>();
            this._logiszConfigManager = LogiszDependencyContainer.Resolve<ILogiszConfigManager>();
        }

        /// <summary>
        /// Return loader view
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            LogiszConfig config = _logiszConfigManager.GetConfig();

            //Validate for developer
            if (!_logiszUserManager.GetLoggedOnUser().IsDeveloper)
                return null;

            return View("~/Logisz/Core/Modules/DashboardInformation/Views/Dashboard.cshtml", config.Core.CoreModules.Dashboard);
        }
    }
}