﻿
const expandActionName = "expand";
const expandableActionName = "expandable";
const expandCssClass = "LogiszDashboard_Expanded";
const collapsedCssClass = "LogiszDashboard_Collapsed";
const LogiszDashboardCollapsedProperty = "data-collapsed";

//Collapse features

$(document).ready(function () {
    $("[data-action='" + expandActionName + "']").on("click", function () {

        let obj = $(this).parent().find("[data-action='" + expandableActionName + "']").first();
        if (obj.hasClass(expandCssClass)) {
            obj.removeClass(expandCssClass);
            obj.addClass(collapsedCssClass);

            $(this).removeClass(expandCssClass);
        } else {
            obj.removeClass(collapsedCssClass);
            obj.addClass(expandCssClass);

            $(this).addClass(expandCssClass);
        }

    });

})
