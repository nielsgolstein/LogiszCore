﻿using SitefinityWebApp.Logisz.Core.Exceptions;
using System;
using System.Runtime.Serialization;

namespace SitefinityWebApp.Logisz.Core.Utilities.Exceptions
{
    [Serializable]
    internal class LogiszStringParseException : LogiszException
    {
        public LogiszStringParseException(string location) : base(location)
        {
            
        }

        public LogiszStringParseException(string location, string message) : base(location, message)
        {
        }

        public LogiszStringParseException(string location, string message, Exception innerException) : base(location, message, innerException)
        {
        }

        protected LogiszStringParseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}