﻿using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Runtime.Serialization;

namespace SitefinityWebApp.Logisz.Core.Exceptions
{
    /// <summary>
    /// Custom logisz exception base which also automatically logs
    /// </summary>
    public class LogiszException : Exception
    {
        private ILogiszLogger logger { get { return LogiszDependencyContainer.Resolve<ILogiszLogger>(); } }
        private string defaultExceptionMessage = "failed due an error.";

        /// <summary>
        /// Custom exception which automatically logs the thrown exception into the core log.
        /// </summary>
        /// <param name="location">Location from where the exception is thrown</param>
        public LogiszException(string location)
        {
            logger.LogException(FormatMessage(location));
        }

        /// <summary>
        /// Custom exception which automatically logs the thrown exception into the core log.
        /// </summary>
        /// <param name="location">Location from where the exception is thrown</param>
        /// <param name="message">The custom message</param>
        public LogiszException(string location, string message) : base(message)
        {
            logger.LogException(FormatMessage(location, message));
        }

        /// <summary>
        /// Custom exception which automatically logs the thrown exception into the core log.
        /// </summary>
        /// <param name="location">Location from where the exception is thrown</param>
        /// <param name="message">The custom message</param>
        /// <param name="innerException">The exception</param>
        public LogiszException(string location, string message, Exception innerException) : base(message, innerException)
        {
            logger.LogException(FormatMessage(location, message), innerException);
        }

        protected LogiszException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            
        }

        /// <summary>
        /// Formats the location to a message
        /// </summary>
        /// <returns></returns>
        private string FormatMessage(string location, string message = null)
        {
            message = message ?? defaultExceptionMessage;
            return location + ": " + message;
        }
    }
}