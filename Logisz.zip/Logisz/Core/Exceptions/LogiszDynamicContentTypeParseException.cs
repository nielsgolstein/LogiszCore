﻿using SitefinityWebApp.Logisz.Core.Exceptions;
using System;
using System.Runtime.Serialization;

namespace SitefinityWebApp.Logisz.Core.Utilities.Exceptions
{
    [Serializable]
    internal class LogiszDynamicContentTypeParseException : LogiszException
    {
        public LogiszDynamicContentTypeParseException(string location) : base(location)
        {
        }

        public LogiszDynamicContentTypeParseException(string location, string message) : base(location, message)
        {
        }

        public LogiszDynamicContentTypeParseException(string location, string message, Exception innerException) : base(location, message, innerException)
        {
        }

        protected LogiszDynamicContentTypeParseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}