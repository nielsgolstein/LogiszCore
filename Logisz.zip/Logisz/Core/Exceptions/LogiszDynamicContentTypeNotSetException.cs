﻿using System;
using System.Runtime.Serialization;

namespace SitefinityWebApp.Logisz.Core.Exceptions
{
    [Serializable]
    internal class LogiszDynamicContentTypeNotSetException : LogiszException
    {
        public LogiszDynamicContentTypeNotSetException(string location) : base(location)
        {
        }

        public LogiszDynamicContentTypeNotSetException(string location, string message) : base(location, message)
        {
        }

        public LogiszDynamicContentTypeNotSetException(string location, string message, Exception innerException) : base(location, message, innerException)
        {
        }

        protected LogiszDynamicContentTypeNotSetException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            
        }
    }
}