﻿using System;
using System.Runtime.Serialization;

namespace SitefinityWebApp.Logisz.Core.Exceptions
{
    [Serializable]
    internal class LogiszDynamicContentParentNotDefinedException : LogiszException
    {
        public LogiszDynamicContentParentNotDefinedException(string location) : base(location)
        {

        }

        public LogiszDynamicContentParentNotDefinedException(string location, string message) : base(location, message)
        {
        }

        public LogiszDynamicContentParentNotDefinedException(string location, string message, Exception innerException) : base(location, message, innerException)
        {
        }

        protected LogiszDynamicContentParentNotDefinedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}