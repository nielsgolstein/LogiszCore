﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Sitefinity.Configuration;

namespace SitefinityWebApp.Logisz.Core.Configurations
{
    public interface ILogiszConfigManager
    {
        /// <summary>
        /// Register config
        /// </summary>
        /// <typeparam name="T"></typeparam>
        void RegisterLogiszConfig<T>() where T : ConfigSection, new();

        /// <summary>
        /// Get the core config, if the config is not yet created or added (In case our config manager is NOT yet 
        /// initialized), this method will register the configuration.
        /// </summary>
        /// <returns><see cref="LogiszConfig"/></returns>
        LogiszConfig GetConfig();
    }
}
