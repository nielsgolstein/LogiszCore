﻿using SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules;
using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Core
{
    public class LogiszCoreConfig : ConfigElement
    {
        public LogiszCoreConfig(ConfigElement parent) : base(parent) { }

        /// <summary>
        /// Modules section
        /// </summary>
        [ObjectInfo(Title = "Modules", Description = "All logisz core module settings.")]
        [ConfigurationProperty("CoreModules")]
        public LogiszCoreModulesConfig CoreModules
        {
            get
            {
                return (LogiszCoreModulesConfig)this["CoreModules"];
            }
        }

        /// <summary>
        /// Developername role
        /// </summary>
        [ObjectInfo(Title = "The developer role", Description = "Name of the role of a Logisz developer. This role is automatically registered on initialization")]
        [ConfigurationProperty("DeveloperRoleName", DefaultValue = "Developer", IsRequired = true)]
        public string DeveloperRoleName
        {
            get { return (string)this["DeveloperRoleName"]; }
            set { this["DeveloperRoleName"] = value; }
        }

        /// <summary>
        /// Default module path
        /// </summary>
        [ObjectInfo(Title = "Default module path", Description = "The path where all logisz modules should be")]
        [ConfigurationProperty("DefaultModulePath", DefaultValue = "~/Logisz/Modules/", IsRequired = true)]
        public string DefaultModulePath
        {
            get { return (string)this["DefaultModulePath"]; }
            set { this["DefaultModulePath"] = value; }
        }

    }
}