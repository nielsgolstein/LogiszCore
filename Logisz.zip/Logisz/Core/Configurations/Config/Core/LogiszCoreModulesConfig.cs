﻿using SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Dashboard;
using SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Debugger;
using SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Logger;
using SitefinityWebApp.Logisz.Modules.Config;
using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules
{
    public class LogiszCoreModulesConfig : ConfigElement
    {
        public LogiszCoreModulesConfig(ConfigElement parent) : base(parent) { }

        [ObjectInfo(Title = "Logisz debug module", Description = "")]
        [ConfigurationProperty("Debugger")]
        public LogiszDebuggerModuleConfig Debugger
        {
            get { return (LogiszDebuggerModuleConfig)this["Debugger"]; }
            set { this["Debugger"] = value; }
        }

        [ObjectInfo(Title = "Logisz dashboard module", Description = "")]
        [ConfigurationProperty("Dashboard")]
        public LogiszDashboardModuleConfig Dashboard
        {
            get { return (LogiszDashboardModuleConfig)this["Dashboard"]; }
            set { this["Dashboard"] = value; }
        }

        [ObjectInfo(Title = "Logisz logger", Description = "")]
        [ConfigurationProperty("LogiszLogger")]
        public LogiszLoggerConfig Logger
        {
            get { return (LogiszLoggerConfig)this["LogiszLogger"]; }
            set { this["LogiszLogger"] = value; }
        }

        //[ObjectInfo(Title = "Logisz Synchronizer", Description = "")]
        //[ConfigurationProperty("LogiszSynchronizer")]
        //public LogiszSynchronizationModuleConfig Synchronizer
        //{
        //    get { return (LogiszSynchronizationModuleConfig)this["LogiszSynchronizer"]; }
        //    set { this["LogiszSynchronizer"] = value; }
        //}

    }
}