﻿using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Dashboard
{
    public class LogiszDashboardModuleConfig : ConfigElement
    {
        public LogiszDashboardModuleConfig(ConfigElement parent) : base(parent) { }

        [ObjectInfo(Title = "Dashboard collapsing", Description = "True if the dashboard is collapsed and collapsable")]
        [ConfigurationProperty("Collapsed", DefaultValue = false, IsRequired = true)]
        public bool Collapsed
        {
            get { return (bool)this["Collapsed"]; }
            set { this["Collapsed"] = value; }
        }
    }
}