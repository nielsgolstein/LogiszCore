﻿using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Debugger
{
    public class LogiszDebuggerModuleConfig : ConfigElement
    {
        public LogiszDebuggerModuleConfig(ConfigElement parent) : base(parent) { }

        [ObjectInfo(Title = "Default viewpath", Description = "")]
        [ConfigurationProperty("DefaultOutputViewPath", DefaultValue = "~/Logisz/Core/Modules/Debugger/Views/", IsRequired = true)]
        public string DefaultOutputViewPath
        {
            get { return (string)this["DefaultOutputViewPath"]; }
            set { this["DefaultOutputViewPath"] = value; }
        }

        [ObjectInfo(Title = "Default view", Description = "Name of the default debugger output view")]
        [ConfigurationProperty("DefaultOutputViewName", DefaultValue = "DebugDefaultItem", IsRequired = true)]
        public string DefaultOutputViewName
        {
            get { return (string)this["DefaultOutputViewName"]; }
            set { this["DefaultOutputViewName"] = value; }
        }

        [ObjectInfo(Title = "Session name", Description = "Name of the session which is used to communicate the debug data")]
        [ConfigurationProperty("SessionName", DefaultValue = "LogiszDebugSession", IsRequired = true)]
        public string SessionName
        {
            get { return (string)this["SessionName"]; }
            set { this["SessionName"] = value; }
        }

        [ObjectInfo(Title = "Debugger collapsing", Description = "True if the debugger is collapsed by default")]
        [ConfigurationProperty("Collapsed", DefaultValue = false, IsRequired = true)]
        public bool Collapsed
        {
            get { return (bool)this["Collapsed"]; }
            set { this["Collapsed"] = value; }
        }

        [ObjectInfo(Title = "Visible", Description = "If true, the debugger is always visible for core debug, the debugger will automatically being collapsed if there is no module debugging.")]
        [ConfigurationProperty("AlwaysVisible", DefaultValue = true, IsRequired = true)]
        public bool AlwaysVisible
        {
            get { return (bool)this["AlwaysVisible"]; }
            set { this["AlwaysVisible"] = value; }
        }
    }
}