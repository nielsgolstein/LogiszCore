﻿using SitefinityWebApp.Logisz.Core.Configurations.Config.Shared;
using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Core.Modules.Logger
{
    public class LogiszLoggerConfig : ConfigElement
    {
        public LogiszLoggerConfig(ConfigElement parent) : base(parent) { }


        [ObjectInfo(Title = "Clear log on initialize", Description = "When true, the log is being cleared on Initialize")]
        [ConfigurationProperty("ClearOnInitialize", DefaultValue = true, IsRequired = true)]
        public bool ClearOnInitialize
        {
            get { return (bool)this["ClearOnInitialize"]; }
            set { this["ClearOnInitialize"] = value; }
        }

    }
}