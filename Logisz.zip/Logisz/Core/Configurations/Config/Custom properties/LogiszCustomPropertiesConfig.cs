﻿using SitefinityWebApp.Logisz.Core.Configurations.Config.Shared;
using System.Configuration;
using Telerik.Sitefinity.Configuration;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config
{
    public class LogiszCustomPropertiesConfig : ConfigElement
    {
        public LogiszCustomPropertiesConfig(ConfigElement parent) : base(parent) { }


        [ConfigurationProperty("LogiszProperties")]
        public ConfigElementDictionary<string, LogiszKeyValueElement> LogiszProperties
        {
            get
            {
                return (ConfigElementDictionary<string, LogiszKeyValueElement>)this["LogiszProperties"];
            }
        }



        /// <summary>
        /// Gets a custom value
        /// </summary>
        /// <param name="key">key of the setting</param>
        /// <returns>string || null</returns>
        public string GetValue(string key)
        {
            LogiszKeyValueElement e = this.LogiszProperties.ContainsKey(key) ? this.LogiszProperties[key] : null;

            return e != null ? e.Value : string.Empty ;
        }
        
    }
}