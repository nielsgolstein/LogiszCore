﻿using System.Configuration;
using Telerik.Sitefinity.Configuration;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Shared
{
    /// <summary>
    /// Determines a key - value paired config setting.
    /// </summary>
    public class LogiszKeyValueElement : ConfigElement
    {
        public LogiszKeyValueElement(ConfigElement parent) : base(parent) { }

        /// <summary>
        /// The required and unique key
        /// </summary>
        [ConfigurationProperty("Key", IsRequired = true, IsKey = true)]
        public string Key
        {
            get { return (string)this["Key"]; }
            set { this["Key"] = value; }
        }

        /// <summary>
        /// The value of the key.
        /// </summary>
        [ConfigurationProperty("Value", IsRequired = false)]
        public string Value
        {
            get { return (string)this["Value"]; }
            set { this["Value"] = value; }
        }
    }
}