﻿using System.Configuration;
using Telerik.Sitefinity.Configuration;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Shared
{
    /// <summary>
    /// Determines a key - value paired config setting.
    /// </summary>
    public class LogiszSingleKeyElement : ConfigElement
    {
        public LogiszSingleKeyElement(ConfigElement parent) : base(parent) { }

        /// <summary>
        /// The required and unique key
        /// </summary>
        [ConfigurationProperty("Key", IsRequired = true, IsKey = true)]
        public string Key
        {
            get { return (string)this["Key"]; }
            set { this["Key"] = value; }
        }
    }
}