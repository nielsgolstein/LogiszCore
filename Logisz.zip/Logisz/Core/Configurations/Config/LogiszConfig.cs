﻿using SitefinityWebApp.Logisz.Core.Configurations.Config.Core;
using SitefinityWebApp.Logisz.Core.Configurations.Config.Modules;
using SitefinityWebApp.Logisz.Core.Configurations.Config.Shared;
using SitefinityWebApp.Logisz.Modules.Config;
using System.Configuration;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;
using Telerik.Sitefinity.Services;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config
{
    public class LogiszConfig : ConfigSection
    {
        #region Settings

        [ConfigurationProperty("Companyname", DefaultValue = "Logisz B.V.", IsRequired = true)]
        public string CompanyName
        {
            get { return (string)this["Companyname"]; }
            set { this["Companyname"] = value; }
        }

        #endregion


        /// <summary>
        /// Core section
        /// </summary>
        [ObjectInfo(Title = "Logisz Core settings", Description = "Cotains all logisz core settings.")]
        [ConfigurationProperty("Core")]
        public LogiszCoreConfig Core
        {
            get
            {
                return (LogiszCoreConfig)this["Core"];
            }
        }


        /// <summary>
        /// Modules section
        /// </summary>
        [ObjectInfo(Title = "Logisz modules", Description = "Contains all logisz modules settings.")]
        [ConfigurationProperty("Modules")]
        public LogiszModulesConfig Modules
        {
            get
            {
                return (LogiszModulesConfig)this["Modules"];
            }
        }

        /// <summary>
        /// Custom properties
        /// </summary>
        [ObjectInfo(Title = "Custom properties", Description = "Allows us to create custom key-value properties.")]
        [ConfigurationProperty("CustomProperties")]
        public LogiszCustomPropertiesConfig CustomProperties
        {
            get
            {
                return (LogiszCustomPropertiesConfig)this["CustomProperties"];
            }
        }


        #region functions

        /// <summary>
        /// Gets the value of a custom property
        /// </summary>
        /// <param name="key">The key</param>
        /// <returns>String</returns>
        public string GetCustomPropertyValue(string key, string valueToAddIfEmpty = null)
        {
            string result = CustomProperties.GetValue(key);

            //If null or empty, create it...
            if (!string.IsNullOrEmpty(valueToAddIfEmpty) && string.IsNullOrEmpty(result))
            {
                LogiszKeyValueElement elementToAdd = new LogiszKeyValueElement(CustomProperties.LogiszProperties)
                {
                    Key = key,
                    Value = valueToAddIfEmpty
                };
                CustomProperties.LogiszProperties.Add(elementToAdd);

                result = elementToAdd.Value;
            }

            return result;
        }

        #endregion
    }
}