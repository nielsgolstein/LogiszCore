﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config
{
    public class LogiszCoreModuleConfigElement : ConfigElement
    {
        public LogiszCoreModuleConfigElement(ConfigElement parent) : base(parent)
        {

        }

        [ObjectInfo(Title = "Activity", Description = "If true, this module is enabled")]
        [ConfigurationProperty("Active", DefaultValue = false, IsRequired = true)]
        public bool Active
        {
            get { return (bool)this["Active"]; }
            set { this["Active"] = value; }
        }
       

        [ObjectInfo(Title = "Debug view", Description = "Name of the view which is used by the LogiszDebugger.")]
        [ConfigurationProperty("DebugViewName", DefaultValue = "DebugDefaultItem", IsRequired = true)]
        public string DebugViewName
        {
            get { return (string)this["DebugViewName"]; }
            set { this["DebugViewName"] = value; }
        }
    }
}