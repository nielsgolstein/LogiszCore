﻿using SitefinityWebApp.Logisz.Modules.Config;
using System.Configuration;
using Telerik.Sitefinity.Configuration;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config.Modules
{
    public class LogiszModulesConfig : ConfigElement
    {
        public LogiszModulesConfig(ConfigElement parent) : base(parent) { }


        /// <summary>
        /// Page title handler
        /// </summary>
        [ConfigurationProperty("PageTitleHandler")]
        public LogiszPageTitleHandlerConfig PageTitleHandler
        {
            get { return (LogiszPageTitleHandlerConfig)this["PageTitleHandler"]; }
            set { this["PageTitleHandler"] = value; }

        }

        /// <summary>
        /// Shortcoder
        /// </summary>
        [ConfigurationProperty("Shortcoder")]
        public Shortcoder Shortcoder
        {
            get { return (Shortcoder)this["Shortcoder"]; }
            set { this["Shortcoder"] = value; }

        }

        /// <summary>
        /// OpenGraph
        /// </summary>
        [ConfigurationProperty("Opengraph")]
        public OpengraphConfig Opengraph
        {
            get { return (OpengraphConfig)this["Opengraph"]; }
            set { this["Opengraph"] = value; }

        }


        [ConfigurationProperty("Yoast")]
        public YoastConfig Yoast
        {
            get { return (YoastConfig)this["Yoast"]; }
            set { this["Yoast"] = value; }

        }

        [ConfigurationProperty("Hreflang")]
        public HrefLangConfig Hreflang
        {
            get { return (HrefLangConfig)this["Hreflang"]; }
            set { this["Hreflang"] = value; }

        }

    }
}