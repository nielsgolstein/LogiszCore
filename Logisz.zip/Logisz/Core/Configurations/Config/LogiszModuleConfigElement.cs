﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Localization;

namespace SitefinityWebApp.Logisz.Core.Configurations.Config
{
    public class LogiszModuleConfigElement : ConfigElement
    {
        public LogiszModuleConfigElement(ConfigElement parent) : base(parent)
        {

        }

        [ObjectInfo(Title = "Activity", Description = "If true, this module is enabled")]
        [ConfigurationProperty("Active", DefaultValue = false, IsRequired = true)]
        public bool Active
        {
            get { return (bool)this["Active"]; }
            set { this["Active"] = value; }
        }

        [ObjectInfo(Title = "Debug mode", Description = "Represents if this module is in debug mode.")]
        [ConfigurationProperty("Debug", DefaultValue = false, IsRequired = true)]
        public bool Debug
        {
            get { return (bool)this["Debug"]; }
            set { this["Debug"] = value; }
        }

        [ObjectInfo(Title = "Debug view", Description = "Path and of the view which is used by the LogiszDebugger.")]
        [ConfigurationProperty("DebugViewName", DefaultValue = "DebugDefaultItem", IsRequired = true)]
        public string DebugViewName
        {
            get { return (string)this["DebugViewName"]; }
            set { this["DebugViewName"] = value; }
        }
    }
}