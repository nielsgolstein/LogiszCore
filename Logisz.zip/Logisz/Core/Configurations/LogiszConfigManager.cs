﻿using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.System.Logger;
using Telerik.Sitefinity.Configuration;

namespace SitefinityWebApp.Logisz.Core.Configurations
{
    /// <summary>
    /// Auto register configs
    /// </summary>
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_CORE_INITIALIZE)]
    public sealed class LogiszConfigManager : ILogiszAutoInitialize, ILogiszConfigManager
    {
        #region Attributes

        public static bool RegisteredConfigurations { get; private set; }
        private readonly ILogiszLogger _logiszLogger;

        #endregion

        #region Constructor

        private LogiszConfigManager(ILogiszLogger logiszLogger)
        {
            this._logiszLogger = logiszLogger;
        }

        #endregion

        /// <summary>
        /// Register Logisz configurations
        /// </summary>
        private void RegisterLogiszConfigs()
        {
            if (RegisteredConfigurations)
                return;

            RegisterLogiszConfig<LogiszConfig>();
            RegisterLogiszConfig<ClientConfig>();
            RegisteredConfigurations = true;
        }


        /// <summary>
        /// Register config
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public void RegisterLogiszConfig<T>() where T : ConfigSection, new()
        {
            _logiszLogger.Log("ConfigManager: Registered section " + typeof(T).Name);

            Telerik.Sitefinity.Configuration.Config.RegisterSection<T>();
        }


        /// <summary>
        /// Get the core config, if the config is not yet created or added (In case our config manager is NOT yet 
        /// initialized), this method will register the configuration.
        /// </summary>
        /// <returns><see cref="LogiszConfig"/></returns>
        public LogiszConfig GetConfig() {
            //Try register config
            if (!RegisteredConfigurations) {
                RegisterLogiszConfigs();
            }

            return Telerik.Sitefinity.Configuration.Config.Get<LogiszConfig>();
        }


        /// <summary>
        /// Auto init
        /// </summary>
        public void AutoInitialize()
        {
            RegisterLogiszConfigs();
            //GetInstance();
        }
    }
}