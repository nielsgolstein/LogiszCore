﻿namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    /// <summary>
    /// Transaction actions which are used to do action on create or update events
    /// </summary>
    public enum LogiszTransitionActions
    {
        /// <summary>
        /// Is valid for creating AND updating data.
        /// </summary>
        CREATE_AND_UPDATE,

        /// <summary>
        /// Is valid for only creating data.
        /// </summary>
        CREATE_ONLY,

        /// <summary>
        /// Is valid for only updating data.
        /// </summary>
        UPDATE_ONLY
    }
}