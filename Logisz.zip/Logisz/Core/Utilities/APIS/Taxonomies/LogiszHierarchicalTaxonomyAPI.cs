﻿using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Linq;
using System.Text.RegularExpressions;
using Telerik.Sitefinity.Data;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Taxonomies;
using Telerik.Sitefinity.Taxonomies.Model;
using SitefinityWebApp.Logisz.Core.Utilities.Extensions;
using SitefinityWebApp.Logisz.Core.System.Dependency;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    //TODO: Fix inharitance
    public static class LogiszHierarchicalTaxonomyAPI
    {
        #region Attributes
        /// <summary>
        /// Private logger
        /// </summary>
        private static ILogiszLogger _logiszLogger { get { return LogiszDependencyContainer.Resolve<ILogiszLogger>(); } }

        #endregion

        #region Public methods

        /// <summary>
        /// Creates a new classification category
        /// </summary>
        /// <param name="manager"><see cref="TaxonomyManager"/></param>
        /// <param name="name">The name, title and taxonomyname of our group</param>
        /// <param name="taxon">The created taxon</param>
        /// <returns></returns>
        public static Taxonomy CreateOrGetHierachicalTaxonomy(this TaxonomyManager manager, string name)
        {
            try
            {
                //Check if exist
                Taxonomy taxon = GetTaxonomy(name);
                if (taxon != null)
                    return taxon;

                //creates hierarchical taxonomy
                taxon = manager.CreateTaxonomy<HierarchicalTaxonomy>();
                taxon.Title = name;
                taxon.Name = name;
                taxon.TaxonName = name;

                TransactionManager.CommitTransaction(transactionName);
                _logiszLogger.Log("LogiszHierarchicalTaxonomiAPI: Added new taxonomy named " + name + ".", LogiszAPIBase.LOGGER_API_LOGNAME);
                return taxon;
            } catch(Exception e)
            {
                _logiszLogger.LogException("LogiszHierarchicalTaxonomyAPI: Failed to create Taxonomy "+ name + " using the Logisz API. ", e);
            }
            return null;
        }


        /// <summary>
        /// Overloaded method for CreateOrGetHierachicalTaxonomy
        /// </summary>
        /// <param name="name">The name of the taxonomy</param>
        /// <param name="manager">The manager</param>
        /// <returns><see cref="Taxonomy"/></returns>
        public static Taxonomy CreateOrGetHierachicalTaxonomy(string name, bool supressSecurityChecks = false, TaxonomyManager manager = null)
        {
            manager = manager ?? GetTaxonomyManager();

            Taxonomy taxonomy = manager.CreateOrGetHierachicalTaxonomy(name);

            return taxonomy;
        }


        /// <summary>
        /// Creates or gets a Hierachical taxon, or better called: A classification
        /// </summary>
        /// <param name="name">Name of the classification</param>
        /// <param name="parentName">Name of the group or category</param>
        /// <returns><see cref="HierarchicalTaxon"/></returns>
        public static HierarchicalTaxon CreateOrGetClassification(string name, string parentName, bool supressSecurity = false)
        {
            TaxonomyManager manager = GetTaxonomyManager();
            manager.Provider.SuppressSecurityChecks = supressSecurity;

            HierarchicalTaxon taxon = manager.CreateOrGetClassification(name, String.Empty, parentName);

            //Revert
            manager.Provider.SuppressSecurityChecks = false;

            return taxon;
        }


        /// <summary>
        /// Creates a Hierachical taxon, or better called: A classification
        /// </summary>
        /// <param name="manager">The manager <see cref="TaxonomyManager"/></param>
        /// <param name="name">The name of our Classification</param>
        /// <param name="description">The description of our Classification</param>
        /// <param name="parent">The group where our taxonomy belongs to Classification</param>
        /// <returns>Success or failure</returns>
        public static HierarchicalTaxon CreateOrGetClassification(this TaxonomyManager manager, string name, string description, Taxonomy parent)
        {
            try
            {
                Taxon classification = GetClassification(name, parent.Name);
                if (classification != null)
                    return classification as HierarchicalTaxon;

                //creates a new taxon and adds it to the taxonomy - Language Groups
                var rootTaxonCateg = manager.CreateTaxon<HierarchicalTaxon>();
                rootTaxonCateg.Title = name;
                rootTaxonCateg.Name = name;
                rootTaxonCateg.UrlName = new Lstring(Regex.Replace(name, @"[^\w\-\!\$\'\(\)\=\@\d_]+", "-").ToLower());
                rootTaxonCateg.Description = description;
                rootTaxonCateg.Taxonomy = parent;
                parent.Taxa.Add(rootTaxonCateg);

                TransactionManager.CommitTransaction(transactionName);
                _logiszLogger.Log("LogiszHierarchicalTaxonomiAPI: Added new classification named " + name + " in taxonomy " + parent.Title, LogiszAPIBase.LOGGER_API_LOGNAME);
                return rootTaxonCateg;
            }
            catch (Exception e)
            {
                _logiszLogger.LogException("LogiszHierarchicalTaxonomyAPI: Failed to create HierarchicalTaxonomy  " + name + "  using the Logisz API. ", e);
            }

            return null;
        }


        /// <summary>
        /// Creates a Hierachical taxon, or better called: A classification
        /// </summary>
        /// <param name="manager">The manager <see cref="TaxonomyManager"/></param>
        /// <param name="name">The name of our Classification</param>
        /// <param name="description">The description of our Classification</param>
        /// <param name="parentName">The group name where our taxonomy belongs to Classification</param>
        /// <returns></returns>
        public static HierarchicalTaxon CreateOrGetClassification(this TaxonomyManager manager, string name, string description, string parentName)
        {
            //Create taxonomy or get it.
            Taxonomy tax = CreateOrGetHierachicalTaxonomy(parentName, manager.Provider.SuppressSecurityChecks, manager);
            if (tax == null)
                return null;

            return manager.CreateOrGetClassification(name, description, tax);
        }


        /// <summary>
        /// Creates a classification in this category
        /// </summary>
        /// <param name="tax">The taxonomy</param>
        /// <param name="name">Name of our classification</param>
        /// <param name="description">The description</param>
        /// <param name="manager">Optional manager</param>
        /// <param name="supressSecurityChecks">True if everyone can create</param>
        /// <returns><see cref="HierarchicalTaxon"/></returns>
        public static HierarchicalTaxon CreateOrGetClassification(this Taxonomy tax, string name, string description, TaxonomyManager manager = null)
        {
            manager = manager ?? GetTaxonomyManager();

            HierarchicalTaxon taxon = manager.CreateOrGetClassification(name, description, tax);

            return taxon;
        }


        /// <summary>
        /// Gets a taxonomy by name, trims and makes them lowercase to find them.
        /// </summary>
        /// <param name="name">The name</param>
        /// <returns><see cref="Taxonomy"/> or NULL</returns>
        public static Taxonomy GetTaxonomy(string name)
        {
            //Get the taxonomy
            //TODO: Check why we need to perform a: ToList() method before we can use our static method to compare... this gives a error
            return GetTaxonomyManager().GetTaxonomies<HierarchicalTaxonomy>().ToList().FirstOrDefault(tax => tax.Name.LogiszCompareWith(name));
        }


        /// <summary>
        /// Get a classification by name from parent
        /// </summary>
        /// <param name="name">The name</param>
        /// <param name="parentName">The parent name</param>
        /// <returns><see cref="Taxon"/> or NULL</returns>
        public static Taxon GetClassification(string name, string parentName)
        {
            Taxonomy parent = GetTaxonomy(parentName);
            if (parent == null)
                return null;

            return parent.Taxa.ToList().Where(t => t.Name.LogiszCompareWith(name)).FirstOrDefault();
        }

        #endregion

        #region Private methods

        private static string transactionName = "LogiszHierachicalTaxonomyAPItransaction";

        private static TaxonomyManager GetTaxonomyManager()
        {
            return TaxonomyManager.GetManager(String.Empty, transactionName);
        }

        #endregion

    }
}