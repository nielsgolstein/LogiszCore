﻿using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    /// <summary>
    /// Base class for Logisz api's
    /// </summary>
    public abstract class LogiszAPIBase
    {
        /// <summary>
        /// The name of the log file for API's
        /// </summary>
        public static string LOGGER_API_LOGNAME = "APIS";

        /// <summary>
        /// The logger for APIs
        /// </summary>
        protected static ILogiszLogger _logiszLogger { get { return LogiszDependencyContainer.Resolve<ILogiszLogger>(); } }


        /// <summary>
        /// Appends a url with the root
        /// </summary>
        /// <param name="urlPart">Part of url</param>
        /// <returns>Full url</returns>
        public static string AddRootPath(string urlPart)
        {
            //Make sure we and with /
            urlPart = urlPart.First() != '/' ? "/" + urlPart : urlPart;

            string root = GetRootPath();
            return root + urlPart;
        }

        /// <summary>
        /// Gets the path to the root
        /// </summary>
        /// <returns>Root path</returns>
        public static string GetRootPath()
        {
            try
            {
                return HttpContext.Current.Server.MapPath("/");
            } catch(Exception e)
            {
                _logiszLogger.LogException("Failed to receive host path.", e);
            }

            return null;
        }
    }
}