﻿using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Telerik.Sitefinity.Data;
using Telerik.Sitefinity.Libraries.Model;
using Telerik.Sitefinity.Modules.Libraries;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_CORE_INITIALIZE)]
    public sealed class LogiszLibraryAPI : LogiszAPIBase, ILogiszAutoInitialize
    {
        private static LibrariesManager librariesManager { get; set; }
        public static readonly string DefaultAlbumName = "Logisz Core Album";

        #region Initialize

        /// <summary>
        /// Initializer
        /// </summary>
        public void AutoInitialize()
        {
            //Create album if not exists
            librariesManager = LibrariesManager.GetManager(String.Empty, "transactionNameLogiszLibManager");
        }

        #endregion

        /// <summary>
        /// Get a image by name from library
        /// </summary>
        /// <param name="imageName">Name of the image</param>
        /// <param name="albumName">Name of the album</param>
        /// <returns>Image or NULL</returns>
        public static Image GetImageByName(string imageName, string albumName = null)
        {
            //Get all images
            List<Image> images = librariesManager.GetImages().ToList();

            //Validate album
            if(!String.IsNullOrEmpty(albumName))
            {
                //Get album
                Album album = GetAlbumByName(albumName);
                if (album == null)
                    return null;
                images = images.Where(q => q.Album.Id == album.Id).ToList();
            }

            Image image = images.FirstOrDefault(q => q.Title.LogiszCompareWith(imageName));

            return image;
        }


        /// <summary>
        /// Adds a image to the library
        /// </summary>
        /// <param name="Url">Url to the image</param>
        /// <param name="AlbumName">Name of the album</param>
        public static void AddImageToLibraryByPath(string Path, string AlbumName = null, bool suppressSecurity = false)
        {
            try
            {
                AlbumName = AlbumName ?? DefaultAlbumName;

                ///Parse to URL
                Uri uri = new Uri(AddRootPath(Path));
                string imageName = uri.Segments.Last();

                ///Select album
                Album album = CreateOrGetAlbumByName(AlbumName, suppressSecurity);
                if (album == null)
                    return;

                #region Add the image to SF
                Image image;

                //The album post is created as master. The masterImageId is assigned to the master version.
                if (suppressSecurity)
                    librariesManager.Provider.SuppressSecurityChecks = true;

                image = librariesManager.CreateImage(Guid.NewGuid());

                //Set the parent album.
                image.Parent = album;

                //Set the properties of the album post.
                image.Title = imageName;
                image.DateCreated = DateTime.UtcNow;
                image.PublicationDate = DateTime.UtcNow;
                image.LastModified = DateTime.UtcNow;
                image.UrlName = imageName.ToUrlFriendly();
                image.MediaFileUrlName = imageName.ToUrlFriendly();

                //Upload the image file.
                Stream stream = GetImageStreamByPath(uri.AbsolutePath);
                string extension = ".png";

                //TODO: Fix uploading image by url
                librariesManager.Upload(image, stream, extension);

                //Save the changes.
                TransactionManager.CommitTransaction(librariesManager.TransactionName);

                ///Revery security checks
                if (suppressSecurity)
                    librariesManager.Provider.SuppressSecurityChecks = false;

                _logiszLogger.Log("LogiszLibraryApi: Added image named " + image.Title + " to album " + AlbumName, LOGGER_API_LOGNAME);

                #endregion
            }
            catch (Exception e)
            {
                _logiszLogger.LogException("Failed to add image to library: " + Path + ".", e);
            }
      
        }


        /// <summary>
        /// Gets image from stream
        /// </summary>
        /// <param name="Path">Path of the image</param>
        /// <returns></returns>
        private static Stream GetImageStreamByPath(string path)
        {
            byte[] buff = File.ReadAllBytes(path);
            MemoryStream ms = new MemoryStream(buff);


            return ms;
        }



        #region Albums

        /// <summary>
        /// Creates or gets a album
        /// </summary>
        /// <param name="name">The album name</param>
        /// <returns><see cref="Album"/></returns>
        public static Album CreateOrGetAlbumByName(string name, bool suppressSecurity = false)
        {
            try
            {
                if (suppressSecurity)
                    librariesManager.Provider.SuppressSecurityChecks = true;

                Album album = GetAlbumByName(name);

                if (album == null)
                {
                    //Create the album.
                    album = librariesManager.CreateAlbum();

                    //Set the properties of the album.
                    album.Title = name;
                    album.DateCreated = DateTime.UtcNow;
                    album.LastModified = DateTime.UtcNow;
                    album.UrlName = name.ToUrlFriendly();

                    //Recompiles and validates the url of the album.
                    librariesManager.RecompileAndValidateUrls(album);

                    TransactionManager.CommitTransaction(librariesManager.TransactionName);

                    _logiszLogger.Log("LogiszLibraryApi: Added album named " + name, LOGGER_API_LOGNAME);
                    return CreateOrGetAlbumByName(name);
                }

                ///Revery security checks
                if (suppressSecurity)
                    librariesManager.Provider.SuppressSecurityChecks = false;

                return album;
            } catch(Exception e)
            {
                _logiszLogger.LogException("Failed to create image album: " + name, e);
                return null;
            }
        }

        /// <summary>
        /// Gets a album by name
        /// </summary>
        /// <param name="name">Name of the album</param>
        /// <returns><see cref="Album"/> or NULL</returns>
        private static Album GetAlbumByName(string name)
        {
            return librariesManager.GetAlbums().ToList().FirstOrDefault(q => q.Title.LogiszCompareWith(name));
        }

        #endregion

    }
}