﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.DynamicModules.Model;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public static class DynamicContentExtensionMethods
    {

        /// <summary>
        /// Get only the live items
        /// </summary>
        /// <param name="list">Current list</param>
        /// <returns>List<DynamicContent> with only live items</returns>
        public static List<DynamicContent> LiveItems(this List<DynamicContent> list)
        {
            list = list.Where(item => item.Visible == true).ToList();
            list = list.Where(item => item.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live).ToList();
            list = list.Where(item => item.ApprovalWorkflowState == "Published").ToList();
            list = list.Where(item => !item.IsDeleted).ToList();

            return list;
        }

        /// <summary>
        /// Get only the live items
        /// </summary>
        /// <param name="list">Current list</param>
        /// <returns>List<DynamicContent> with only live items</returns>
        public static List<DynamicContent> LiveItems(this IQueryable<DynamicContent> list)
        { return LiveItems(list.ToList()); }

        /// <summary>
        /// Get only the live items
        /// </summary>
        /// <param name="list">Current list</param>
        /// <returns>List<DynamicContent> with only live items</returns>
        public static List<DynamicContent> LiveItems(this IEnumerable<DynamicContent> list)
        { return LiveItems(list.ToList()); }


    }
}