﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Sitefinity.DynamicModules.Model;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public interface ISpecialDynamicContentValueType
    {
        /// <summary>
        /// Indicates if this object type can have relations within our dynamic content
        /// </summary>
        bool CanHaveRelations { get; }

        /// <summary>
        /// Validates the attribute based on diffirent type implementations
        /// </summary>
        /// <param name="attribute">The attribute to validate</param>
        /// <returns>True or false, true if the attribute is valid, false if the attribute is invalid.</returns>
        bool Validate(DynamicContentAttribute attribute);

        /// <summary>
        /// Connects the attribute to the dynamic content based on it's special type enum.
        /// </summary>
        /// <param name="dc">The dynamic content to extend</param>
        /// <param name="attribute">The attribute to connect</param>
        /// <returns>The used <see cref="DynamicContent"/></returns>
        DynamicContent ConnectToDynamicContent(DynamicContent dc, DynamicContentAttribute attribute, CultureInfo culture);
    }
}
