﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    /// <summary>
    /// Special types which are used by the <see cref="LogiszDynamicContentAPI"/> to connect special objects
    /// </summary>
    public enum SpecialDynamicContentValueTypesEnum
    {
        DEFAULT, CLASSIFICATION, IMAGE, DOCUMENT, PARENT
    }

    /// <summary>
    /// Special methods for ENUM <see cref="SpecialDynamicContentValueTypes"/>
    /// </summary>
    public static class SpecialDynamicContentValueTypeMethods
    {

        /// <summary>
        /// Gets the used interface based on the <see cref="SpecialDynamicContentValueTypesEnum"/>. This interface contains
        /// methods for validation, checking and connecting data of this data type.
        /// <para>The default returned type interface is <see cref="LogiszDefault"/></para>
        /// </summary>
        /// <param name="dataType">The type of data as ENUM</param>
        /// <returns><see cref="ISpecialDynamicContentValueType"/></returns>
        public static ISpecialDynamicContentValueType GetInterface(SpecialDynamicContentValueTypesEnum dataType)
        {
            ISpecialDynamicContentValueType contentValueTypeInterface = new LogiszDefault();
            switch (dataType)
            {
                case SpecialDynamicContentValueTypesEnum.IMAGE:
                    contentValueTypeInterface = new LogiszImage();
                    break;
                case SpecialDynamicContentValueTypesEnum.CLASSIFICATION:
                    contentValueTypeInterface = new LogiszClassification();
                    break;
                case SpecialDynamicContentValueTypesEnum.PARENT:
                    contentValueTypeInterface = new LogiszParent();
                    break;
            }

            return contentValueTypeInterface;
        }
    }

}