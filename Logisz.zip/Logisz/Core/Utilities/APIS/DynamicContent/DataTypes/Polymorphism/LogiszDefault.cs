﻿using SitefinityWebApp.Logisz.Core.Utilities.Extensions;
using System.Globalization;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Model;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public class LogiszDefault : ISpecialDynamicContentValueType
    {
        public bool CanHaveRelations { get { return false; } }

        public DynamicContent ConnectToDynamicContent(DynamicContent dc, DynamicContentAttribute attribute, CultureInfo culture)
        {
            if (attribute.Value.IsString())
            {
                //This is a string, set it as string
                dc.SetString(attribute.Key, attribute.Value.ToString(), culture);
            }
            else
            {
                //Some other object?...
                dc.SetValue(attribute.Key, attribute.Value);
            }

            return dc;
        }

        public bool Validate(DynamicContentAttribute attribute)
        {
            return true;
        }
    }
}