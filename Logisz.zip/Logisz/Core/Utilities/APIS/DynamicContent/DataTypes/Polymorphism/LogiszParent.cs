﻿using System.Globalization;
using Telerik.Sitefinity.DynamicModules.Model;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public class LogiszParent : ISpecialDynamicContentValueType
    {
        public bool CanHaveRelations { get { return false; } }

        public DynamicContent ConnectToDynamicContent(DynamicContent dc, DynamicContentAttribute attribute, CultureInfo culture)
        {
            
           return dc;
        }

        public bool Validate(DynamicContentAttribute attribute)
        {
            if (attribute.Value != null)
                return true;
            return false;
        }
    }
}