﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Taxonomies.Model;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public class LogiszClassification : ISpecialDynamicContentValueType
    {

        public bool CanHaveRelations { get { return true; } }

        public DynamicContent ConnectToDynamicContent(DynamicContent dc, DynamicContentAttribute attribute, CultureInfo culture)
        {
            Taxon classification = attribute.Value as Taxon;
            if (classification != null)
            {
                dc.Organizer.AddTaxa(attribute.Key, classification.Id);
            }

            return dc;
        }

        public bool Validate(DynamicContentAttribute attribute)
        {
            if (attribute.Value != null)
                return true;
            return false;
        }
    }
}