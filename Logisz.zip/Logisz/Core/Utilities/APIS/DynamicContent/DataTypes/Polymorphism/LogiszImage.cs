﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Libraries.Model;
using Telerik.Sitefinity.RelatedData;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public class LogiszImage : ISpecialDynamicContentValueType
    {
        public bool CanHaveRelations { get { return false; } }

        public DynamicContent ConnectToDynamicContent(DynamicContent dc, DynamicContentAttribute attribute, CultureInfo culture)
        {
            Image image = attribute.Value as Image;
            if (image != null)
            {
                dc.CreateRelation(image, attribute.Key);
            }

            return dc;
        }

        public bool Validate(DynamicContentAttribute attribute)
        {
            if (attribute.Value != null)
                return true;
            return false;
        }
    }
}