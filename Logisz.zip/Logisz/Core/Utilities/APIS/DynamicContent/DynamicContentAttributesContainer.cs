﻿
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.Extensions;
using SitefinityWebApp.Logisz.Core.System.Logger;
using SitefinityWebApp.Logisz.Core.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Model;
using SitefinityWebApp.Logisz.Core.Exceptions;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    /// <summary>
    /// A data container which is setted up to be inserted into the <see cref="DynamicModuleManager"/> of sitefinity.
    /// Using this container we are easily able to connect classifications, images, string, numbers etc. To our new Dynamic content object
    /// </summary>
    public sealed class DynamicContentAttributesContainer
    {
        #region Attributes

        /// <summary>
        /// All declared attributes.
        /// </summary>
        public List<DynamicContentAttribute> Attributes { get; private set; }

        /// <summary>
        /// Gets the unique identifier from the Attributes list.
        /// </summary>
        public DynamicContentAttribute UniqueIdentifier { get { return Attributes.FirstOrDefault(attr => attr.IsUniqueIdentifier); } }

        /// <summary>
        /// Type of SF which we are going to create or update
        /// </summary>
        private Type DataType { get; set; }

        /// <summary>
        /// The parent of this container data item
        /// </summary>
        private DynamicContent Parent { get; set; }

        /// <summary>
        /// Indicates if this data container needs a parent based on it's data type.
        /// </summary>
        public bool DataTypeNeedsParent { get; private set; }

        private readonly ILogiszLogger _logiszLogger;

        #endregion

        #region Construction

        private DynamicContentAttributesContainer(List<DynamicContentAttribute> attributes)
        {
            this._logiszLogger = LogiszDependencyContainer.Resolve<ILogiszLogger>();
            this.Attributes = attributes;
        }

        /// <summary>
        /// Explicit operator to cast list to container
        /// </summary>
        /// <param name="attributes">The attributes</param>
        public static explicit operator DynamicContentAttributesContainer(List<DynamicContentAttribute> attributes)
        {
            return new DynamicContentAttributesContainer(attributes);
        }

        #endregion

        #region Commit methods

        /// <summary>
        /// Commits the container using the <see cref="LogiszDynamicContentAPI"/>.
        /// <para>Commits can return a <see cref="LogiszDynamicContentTypeNotSetException"/> when the datatype is not set.</para>
        /// <para>Throws default exception upon failing to commit.</para>
        /// </summary>
        /// <param name="culture">Culture to save object in</param>
        /// <param name="suppressSecurityChecks">suppressSecurityChecks</param>
        /// <returns>Success or failure as <see cref="bool"/></returns>
        public bool Commit(CultureInfo culture = null, bool suppressSecurityChecks = false)
        {
            if (DataType == null)
                throw new LogiszDynamicContentTypeNotSetException("DynamicContentAttributesContainer", "Failed to commit changes, datatype is not set.");

            DynamicModuleManager manager = DynamicModuleManager.GetManager(String.Empty, "trans");

            ///Create the item
            bool success = LogiszDynamicContentAPI.CreateDC(this, culture, suppressSecurityChecks: suppressSecurityChecks);

            if(!success)
            {
                _logiszLogger.Log("Something went wrong, the item " + DataType.Name + " with " + UniqueIdentifier.Key + " " + UniqueIdentifier.Value + " is not inserted or updated.");
            }

            return success;
        }

        #endregion

        #region Validation

        /// <summary>
        /// Checks if all attributes are valid and if there is a unique identifier
        /// </summary>
        public bool IsValid { get { return ValidateContainer(); } }

        /// <summary>
        /// Checks if this container is valid for creation
        /// </summary>
        /// <returns></returns>
        private bool ValidateContainer()
        {
            //Contains unique identifier
            if (!ContainsUniqueIdentifier())
                return false;

            //If only one is not valid, return false
            if (Attributes.Any(attr => !attr.IsValid))
                return false;

            //Validate if datatype is set
            if (DataType == null)
                return false;

            //Check if unique identifier is string
            if (!UniqueIdentifier.Value.IsString())
                return false;

            return true;
        }

        /// <summary>
        /// Checks if the attributes contains a unique identifier
        /// </summary>
        /// <returns></returns>
        private bool ContainsUniqueIdentifier()
        {
            if (Attributes.Any(q => q.IsUniqueIdentifier))
                return true;
            return false;
        }

        #endregion

        #region Getters & Setters

        /// <summary>
        /// Sets the used dynamic module datatype which is required to submit changes
        /// </summary>
        /// <param name="typeName">Name of the SF data type</param>
        public void SetDataType(string typeName)
        {
            this.DataType = typeName.ToType();
            this.DataTypeNeedsParent = LogiszDynamicContentAPI.GetParentType(this.DataType) != null;
        }

        /// <summary>
        /// Get the type
        /// </summary>
        /// <returns></returns>
        public Type GetDataType()
        {
            return this.DataType;
        }

        /// <summary>
        /// Set the parent of a dynamic content container
        /// </summary>
        /// <param name="uniqueIdentifier">Unique identifier value</param>
        /// <param name="identifierField">Unique identifier field name</param>
        /// <param name="parentType">Type of the parent</param>
        public void SetParent(string uniqueIdentifier, string identifierField, string parentType, DynamicModuleManager manager = null)
        {
            try
            {
                //Fix manager
                manager = manager ?? DynamicModuleManager.GetManager(String.Empty, "transactionNameForSettingParent");
                Type type = parentType.ToType();

                //Get the parent item
                DynamicContent parent = manager.GetDataItems(type).FirstOrDefault(q => q.GetValue<string>(identifierField) == uniqueIdentifier);

                //Get master
                if(parent.Status !=  Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Master)
                {
                    parent = manager.Lifecycle.GetMaster(parent) as DynamicContent;
                }

                this.Parent = parent;
            }
            catch (Exception e)
            {
                _logiszLogger.LogException("DynamicContentAttributesContainer: Failed to get parent item of type "+ parentType, e);
            }
           
        }

        /// <summary>
        /// Gets the registered parent of the dynamic dontent container.
        /// </summary>
        /// <returns><see cref="DynamicContent"/> or NULL if it is not set.</returns>
        public DynamicContent GetParent()
        {
            return this.Parent;
        }

        #endregion
    }
}