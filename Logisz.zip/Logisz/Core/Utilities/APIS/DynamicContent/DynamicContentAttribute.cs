﻿using System;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    /// <summary>
    /// Specifies a simple property of the module builder whichs holds a Key and a Value. 
    /// </summary>
    public class DynamicContentAttribute
    {
        /// <summary>
        /// The key of our dynamic content
        /// </summary>
        public string Key { get; private set; }

        /// <summary>
        /// The value of our dynamic content
        /// </summary>
        public object Value { get; private set; }

        /// <summary>
        /// If this attribute is the identifier of our dynamic module, set to true.
        /// </summary>
        public bool IsUniqueIdentifier { get; private set; }

        /// <summary>
        /// Type of the object value
        /// </summary>
        public Type ValueType { get; private set; }

        /// <summary>
        /// Defines a special type line CLASSIFICATIONS, IMAGES, ETC.
        /// </summary>
        public SpecialDynamicContentValueTypesEnum SpecialTypeEnum { get; private set; }

        /// <summary>
        /// The special type of our content attribute
        /// </summary>
        public ISpecialDynamicContentValueType SpecialType { get; private set; }

        /// <summary>
        /// Holds the status if we need to update a specific element or not. If the status is the same as this action, it is ok and we are going to update. For example
        /// We are going t UPDATE a module element, but our type said: CREATE_ONLY. We are skipping this type because we do not update it, only on CREATE ONLY
        /// </summary>
        public LogiszTransitionActions ActionType { get; private set; }

        /// <summary>
        /// Checks if this content attribute key - value is valid
        /// </summary>
        public bool IsValid { get; private set; }

        /// <summary>
        /// True if we need to delete relations
        /// </summary>
        public bool DoDeleteRelations { get; private set; }

        /// <summary>
        /// Initialize the object
        /// </summary>
        /// <param name="key">The used key field</param>
        /// <param name="value">The value field</param>
        public DynamicContentAttribute(string key, object value, bool isUniqueIdentifier = false, SpecialDynamicContentValueTypesEnum specialType = SpecialDynamicContentValueTypesEnum.DEFAULT, LogiszTransitionActions actionType = LogiszTransitionActions.CREATE_AND_UPDATE, bool doDeleteRelations = true)
        {
            this.Key = key;
            this.Value = value;
            if(value != null)
                this.ValueType = value.GetType();
            this.IsUniqueIdentifier = isUniqueIdentifier;
            this.SpecialTypeEnum = specialType;
            this.SpecialType = SpecialDynamicContentValueTypeMethods.GetInterface(specialType);
            this.ActionType = actionType;
            this.DoDeleteRelations = doDeleteRelations;

            Validate();
        }

        /// <summary>
        /// Validates the object
        /// </summary>
        private void Validate()
        {
            IsValid = SpecialType.Validate(this);
        }

    }
}