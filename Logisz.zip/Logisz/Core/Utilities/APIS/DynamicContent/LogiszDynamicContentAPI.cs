﻿using System;
using System.Globalization;
using System.Linq;
using Telerik.Sitefinity;
using Telerik.Sitefinity.Data;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Security;
using SitefinityWebApp.Logisz.Core.Utilities.Extensions;
using Telerik.Sitefinity.Taxonomies.Model;
using Telerik.Sitefinity.Lifecycle;
using Telerik.Sitefinity.Libraries.Model;
using Telerik.Sitefinity.RelatedData;
using System.Collections.Generic;
using SitefinityWebApp.Logisz.Core.Extensions;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System.Threading;
using SitefinityWebApp.Logisz.Core.Exceptions;

namespace SitefinityWebApp.Logisz.Core.Utilities.APIS
{
    public sealed class LogiszDynamicContentAPI : LogiszAPIBase
    {
        #region Private attributes

        private static string transactionName = "trans";
        private static string providerName = String.Empty;

        //TODO: Rename logger to _logiszLogger
        private static ILogiszLogger logger { get { return LogiszDependencyContainer.Resolve<ILogiszLogger>(); } }

        #endregion

        #region Public methods


        /// <summary>
        /// Creates a new dynamic content item in the module builder
        /// </summary>
        /// <param name="contentType">The type of the dynamic content</param>
        /// <param name="values">The to use values to fill our model</param>
        /// <param name="urlName">The unique url name</param>
        /// <param name="culture">Culture</param>
        /// <param name="manager">optional <see cref="DynamicModuleManager"/></param>
        /// <param name="suppressSecurityChecks"></param>
        /// <returns>Success as <see cref="bool"/></returns>
        public static bool CreateDC(DynamicContentAttributesContainer attributesContainer, CultureInfo culture = null, DynamicModuleManager manager = null, bool suppressSecurityChecks = false)
        {
            try
            {
                #region Validate attributes and unique identifier
                ///Validates the container

                if (!attributesContainer.IsValid)
                {
                    logger.Log("LogiszDynamicContentAPI: attributes are not valid to be imported", LOGGER_API_LOGNAME);
                    return false;
                }

                Type contentType = attributesContainer.GetDataType();

                #endregion

                #region Setup manager

                manager = manager ?? DynamicModuleManager.GetManager(providerName, transactionName);
                manager.Provider.SuppressSecurityChecks = suppressSecurityChecks;
                if (manager.TransactionName == null)
                    manager.TransactionName = transactionName;

                #endregion

                #region Culture settings

                culture = culture ?? CultureInfo.CurrentCulture;
                CultureInfo oldCulture = CultureInfo.CurrentCulture;

                if (culture.LCID != oldCulture.LCID)
                {
                    //Update culture!
                    Thread.CurrentThread.CurrentCulture = culture;
                    Thread.CurrentThread.CurrentUICulture = culture;
                }
                #endregion

                #region Validate parent

                ValidateParent(attributesContainer);

                #endregion

                #region Receive object to prepare for insert or update

                DynamicContent newContentObject;
                if (attributesContainer.DataTypeNeedsParent)
                {
                    DynamicContent parentItem = attributesContainer.GetParent();
                    List<DynamicContent> tempChildItemsList = parentItem.GetChildItems(attributesContainer.GetDataType().ToString()).ToList();
                    newContentObject = tempChildItemsList.FirstOrDefault(q => 
                        q.GetValue<Lstring>(attributesContainer.UniqueIdentifier.Key).ToString() == attributesContainer.UniqueIdentifier.Value.ToString() &&
                        q.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Master);
                } else
                {
                    ///Without parent
                    newContentObject = manager.GetDataItems(contentType).FirstOrDefault(
                        //TODO: Use LogiszComparable type here, smart or not?!
                        q => q.GetValue<string>(attributesContainer.UniqueIdentifier.Key).ToString() == attributesContainer.UniqueIdentifier.Value.ToString() &&
                        q.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                    );
                }

                
                
                // 1. Create new object if not exist
                bool contentItemAlreadyExisted = newContentObject != null;
                newContentObject = newContentObject ?? manager.CreateDataItem(contentType);

                #endregion

                #region Delete relations which are needed to be deleted (only if this item already existed)

                if (contentItemAlreadyExisted)
                {
                    try
                    {
                        newContentObject = TryRemoveRelations(attributesContainer.Attributes, newContentObject);
                    } catch(Exception e)
                    {
                        manager.CancelChanges();
                        logger.LogException(String.Format("LogiszDynamicContentAPI: failed to remove relation for type {0}", attributesContainer.GetDataType().Name), e);
                        return false;
                    }
                    
                }
                
                #endregion

                // 2. Set object values
                foreach (DynamicContentAttribute dynamicContentValue in attributesContainer.Attributes)
                {

                    #region Check if we need to update this attribute
                    //Check if we need to do something
                    if(dynamicContentValue.ActionType != LogiszTransitionActions.CREATE_AND_UPDATE)
                    {
                        if(contentItemAlreadyExisted)
                        {
                            //If the content item already existed, we are going to update it...
                            if (dynamicContentValue.ActionType == LogiszTransitionActions.CREATE_ONLY)
                                continue;
                        } else
                        {
                            //If the content item did not exist, we are going to create it...
                            if (dynamicContentValue.ActionType == LogiszTransitionActions.UPDATE_ONLY)
                                continue;
                        }
                    }

                    #endregion

                    //Check field existance
                    if (!newContentObject.DoesFieldExist(dynamicContentValue.Key))
                    {
                        logger.Log("LogiszDynamicContentAPI: unknown field named " + dynamicContentValue.Key + " found.");
                        manager.CancelChanges();
                        return false;
                    }

                    dynamicContentValue.SpecialType.ConnectToDynamicContent(newContentObject, dynamicContentValue, culture);
                }

                #region Set parent

                //If we need a parent
                if(attributesContainer.DataTypeNeedsParent)
                {
                    DynamicContent parent = attributesContainer.GetParent();
                    newContentObject.SetParent(parent.Id, parent.GetType().FullName);
                }

                #endregion

                #region Required fields

                newContentObject.SetString("UrlName", attributesContainer.UniqueIdentifier.Value.ToString().ToUrlFriendly(), culture);
                newContentObject.SetValue("Owner", SecurityManager.GetCurrentUserId());
                newContentObject.SetValue("PublicationDate", DateTime.UtcNow);

                //Set published
                newContentObject.SetWorkflowStatus(manager.Provider.ApplicationName, "Published", culture);
                
                #endregion

                #region Commit and fix lifecycle

                //Commit!
                TransactionManager.CommitTransaction(manager.TransactionName);
                if(contentItemAlreadyExisted)
                {
                    logger.Log( String.Format("LogiszDynamicContentAPI: Updated {0} named {1} [{2}]", attributesContainer.GetDataType().Name, attributesContainer.UniqueIdentifier.Value, culture.TwoLetterISOLanguageName), LOGGER_API_LOGNAME);
                } else
                {
                    logger.Log(String.Format("LogiszDynamicContentAPI: Created new {0} named {1} [{2}]", attributesContainer.GetDataType().Name, attributesContainer.UniqueIdentifier.Value, culture.TwoLetterISOLanguageName), LOGGER_API_LOGNAME);
                }

                #region Make sure we have a master

                //Validate the object status for a master state
                if(newContentObject.Status != Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Master)
                {
                    newContentObject = manager.Lifecycle.GetMaster(newContentObject) as DynamicContent;
                }


                #endregion

                manager.Lifecycle.Publish(newContentObject);

                // Use lifecycle so that LanguageData and other Multilingual related values are correctly created
                ILifecycleDataItem checkOutShortcodeItem = manager.Lifecycle.CheckOut(newContentObject, culture);
                ILifecycleDataItem checkInShortcodeItem = manager.Lifecycle.CheckIn(checkOutShortcodeItem, culture);
                TransactionManager.CommitTransaction(manager.TransactionName);
                logger.Log(String.Format("LogiszDynamicContentAPI: Re-commit {0} to fix lifecycle.", attributesContainer.UniqueIdentifier.Value), LOGGER_API_LOGNAME);

                #endregion

                #region Culture settings revert

                if (culture.LCID != oldCulture.LCID)
                {
                    //Update culture!
                    Thread.CurrentThread.CurrentCulture = oldCulture;
                    Thread.CurrentThread.CurrentUICulture = oldCulture;
                }

                #endregion

                //Revert checks, enable it.
                manager.Provider.SuppressSecurityChecks = false;

                return true;
            } catch(Exception e)
            {
                logger.LogException("LogiszDynamicContentAPI: Failed to create dynamic content item " + attributesContainer.UniqueIdentifier.Value + ", ", e);
            }
            return false;
        }


        /// <summary>
        /// Validates the container object if it needs a parent, if the parent is not set when it is needed, a
        ///  <see cref="LogiszDynamicContentParentNotDefinedException"/> is thrown
        /// </summary>
        /// <param name="newContentObject">The new DC object</param>
        /// <param name="attributesContainer">Attribute container</param>
        private static void ValidateParent(DynamicContentAttributesContainer attributesContainer)
        {
            if (attributesContainer.DataTypeNeedsParent)
            {
                //No parent set
                if (attributesContainer.GetParent() == null)
                {
                    throw new LogiszDynamicContentParentNotDefinedException("LogiszDynamicContentAPI", "No parent found");
                }

                //Invalid type
                Type parentType = GetParentType(attributesContainer.GetDataType());
                if (parentType.FullName != attributesContainer.GetParent().GetType().FullName)
                {
                    throw new LogiszDynamicContentParentNotDefinedException("LogiszDynamicContentAPI", "invalid parent");
                }
            }
        }

        #endregion

        /// <summary>
        /// Tries to delete relations if they exist, delete action is NOT commited yet
        /// </summary>
        /// <param name="dc">Dynamic content</param>
        /// <param name="fieldName">Name of the field which holds relations</param>
        /// <returns>DynamicContent</returns>
        private static DynamicContent TryRemoveRelations(List<DynamicContentAttribute> attributes, DynamicContent dc)
        {
            //Group the items by key so we can delete relations for a specific field once.
            List<DynamicContentAttribute> groupedByKey = attributes
                                                         .GroupBy(at => at.Key)
                                                         .Select(gr => gr.First() as DynamicContentAttribute)
                                                         .ToList();

            //Loop to clear relations
            foreach (DynamicContentAttribute dynamicContentAttribute in groupedByKey)
            {
                if (!dynamicContentAttribute.SpecialType.CanHaveRelations)
                    continue;

                if (!dynamicContentAttribute.DoDeleteRelations)
                    continue;

                RemoveRelation(dc, dynamicContentAttribute.Key);
            }

            return dc;
        }

        /// <summary>
        /// Tries to delete relations if they exist, delete action is NOT commited yet
        /// </summary>
        /// <param name="dc">Dynamic content</param>
        /// <param name="fieldName">Name of the field which holds relations</param>
        /// <returns>DynamicContent</returns>
        private static DynamicContent RemoveRelation(DynamicContent dc, string fieldName)
        {
            List<IDataItem> relations = dc.GetRelatedItems(fieldName).ToList();

            dc.DeleteRelations(fieldName);

            return dc;
        }

        /// <summary>
        /// Checks if a type of dynamic content needs a parent type, if not. This method returns NULL
        /// </summary>
        /// <param name="possiblyChildType">The possible child type</param>
        /// <returns><see cref="Type"/> parent type, or NULL if this type has no parent</returns>
        public static Type GetParentType(Type possiblyChildType)
        {
            DynamicModuleManager manager = DynamicModuleManager.GetManager();
            Type parentType = manager.Provider.GetParentType(possiblyChildType);

            return parentType;
        }
    }
}