﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using Telerik.Sitefinity;
using Telerik.Sitefinity.Data;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Lifecycle;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Security;

namespace SitefinityWebApp.Logisz.Core.Utilities.Extensions
{
    /// <summary>
    /// Logisz list extensions
    /// </summary>
    public static class LogiszListExtensions
    {

        
    }
}