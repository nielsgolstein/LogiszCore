﻿using SitefinityWebApp.Logisz.Core.Utilities.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Model;

namespace SitefinityWebApp.Logisz.Core.Utilities.Extensions
{
    /// <summary>
    /// Contains logisz validation extensions
    /// </summary>
    public static class LogiszValidationExtensions
    {

        /// <summary>
        /// Checks if an object is a string
        /// </summary>
        /// <param name="o">The object</param>
        /// <returns>True | False</returns>
        public static bool IsString(this object o)
        {
            Type objectType = o.GetType();

            if (objectType != typeof(string))
                if (objectType != typeof(Lstring))
                    if (objectType != typeof(String))
                        return false;


            return true;
        }

        /// <summary>
        /// Compare a string to another
        /// </summary>
        /// <param name="str1AsObject">First string</param>
        /// <param name="str2AsObject">Second string</param>
        /// <returns>True if equals</returns>
        public static bool LogiszCompareWith(this object str1AsObject, object str2AsObject)
        {
            //Cast Lstring to string.
            string str1 = str1AsObject.LogiszToComparableString();
            string str2 = str2AsObject.LogiszToComparableString();

            return str1 == str2;
        }



        private static string[] filteredCharacters = { " " };
        /// <summary>
        /// Change string or Lstring to a compareable string
        /// </summary>
        /// <param name="str">String object</param>
        /// <returns>String. Throws exception upon NULL or not string castable</returns>
        public static string LogiszToComparableString(this object str)
        {
            if(str == null)
                throw new LogiszStringParseException("LogiszValidationExtensions", "String cannot be null");
            
            //String validation
            if (!str.IsString())
                throw new LogiszStringParseException("LogiszValidationExtensions", "LogiszToComparableString was unable to cast object to string");

            //String cast
            string str1 = str.ToString();

            //ToLower for compare
            str1 = str1.ToLower();
            str1 = str1.Trim();

            //Remove unallowed chars
            foreach(string unallowed in filteredCharacters)
            {
                str1 = str1.Replace(unallowed, String.Empty);
            }

            return str1;
        }

    }
}