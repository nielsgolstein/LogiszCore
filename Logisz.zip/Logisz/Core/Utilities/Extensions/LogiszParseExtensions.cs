﻿using SitefinityWebApp.Logisz.Core.Utilities.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Utilities.TypeConverters;

namespace SitefinityWebApp.Logisz.Core.Utilities.Extensions
{
    /// <summary>
    /// Contains logisz validation extensions
    /// </summary>
    public static class LogiszParseExtensions
    {
        /// <summary>
        /// Type prefix of sitefinity dynamic module content items
        /// </summary>
        private static readonly string DEFAULT_SITEFINIY_DYNAMIC_TYPE_PREFIX = "Telerik.Sitefinity.DynamicTypes.Model.";


        /// <summary>
        /// Transforms a string to a sitefinity type. The prefix Telerik.Sitefinity.DynamicTypes.Model. is not required
        /// <para/>
        /// Exceptions:<para/>
        /// - <see cref="LogiszDynamicContentTypeParseException"/> if parse fails
        /// </summary>
        /// <param name="o">The object</param>
        /// <returns>True | False</returns>
        public static Type ToType(this string str)
        {
            //TODO: Allow str to be only the last 2 segments using the default sf dynamic type prefix
            try
            {
                if (!str.StartsWith(DEFAULT_SITEFINIY_DYNAMIC_TYPE_PREFIX))
                    str = DEFAULT_SITEFINIY_DYNAMIC_TYPE_PREFIX + str;

                Type type = TypeResolutionService.ResolveType(str);
                return type;
            } catch
            {
                throw new LogiszDynamicContentTypeParseException("LogiszParseExtensions", "Failed to parse type " + str);
            }
        }

        /// <summary>
        /// Parses the string to a url save string
        /// </summary>
        /// <param name="str">String</param>
        /// <returns></returns>
        public static string ToUrlFriendly(this string str)
        {
            str = Regex.Replace(str, @"[^A-Za-z0-9_\.~]+", "-");
            return str;
        }

    }
}