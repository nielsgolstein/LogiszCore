﻿
using System;
using Telerik.Sitefinity.Security.Model;

namespace SitefinityWebApp.Logisz.Core.Extensions.Security.Models
{
    /// <summary>
    /// Custom logisz user which holds the user and profile object.
    /// </summary>
    public class LogiszUser
    {
        /// <summary>
        /// IF profile is NULL or the guid is empty, this will be false.
        /// </summary>
        public bool HasProfile { get; private set; }

        /// <summary>
        /// IF user is NULL or the guid is empty, this will be false.
        /// </summary>
        public bool HasUser { get; private set; }

        /// <summary>
        /// The SF user object
        /// </summary>
        public User User { get; private set; }

        /// <summary>
        /// Is this user a admin?
        /// </summary>
        public bool IsAdmin { get; private set; }

        /// <summary>
        /// Is this user a developer?
        /// </summary>
        public bool IsDeveloper { get; private set; }

        /// <summary>
        /// The SF profile object
        /// </summary>
        public SitefinityProfile Profile { get; private set; }

        /// <summary>
        /// Initialize the user object
        /// </summary>
        /// <param name="user">The user</param>
        /// <param name="profile">Profile</param>
        /// <param name="logiszUserManager">Manager</param>
        public LogiszUser(User user, SitefinityProfile profile, LogiszUserManager logiszUserManager)
        {
            this.User = user;
            this.Profile = profile;

            //Validate
            this.HasUser = User == null ? false : true;
            if(HasUser)
                this.HasUser = User.Id == Guid.Empty ? false : true;

            //Validate
            this.HasProfile = Profile == null ? false : true;
            if (HasProfile)
                this.HasProfile = Profile.Id == Guid.Empty ? false : true;


            //Check roles
            IsDeveloper = logiszUserManager.UserIsDeveloper(this);
            IsAdmin = logiszUserManager.UserIsAdmin(this);
        }
    }
}