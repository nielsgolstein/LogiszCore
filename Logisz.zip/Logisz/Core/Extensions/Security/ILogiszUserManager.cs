﻿using SitefinityWebApp.Logisz.Core.Extensions.Security.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Sitefinity.Security;

namespace SitefinityWebApp.Logisz.Core.Extensions.Security
{
    public interface ILogiszUserManager
    {

        #region Public methods

        /// <summary>
        /// Gets the current user and profile object as LogiszUser
        /// </summary>
        /// <returns>LogiszUser object</returns>
        LogiszUser GetLoggedOnUser();


        /// <summary>
        /// Gets the current user and profile object as LogiszUser
        /// </summary>
        /// <returns>LogiszUser object</returns>
        LogiszUser GetUserById(Guid id);


        /// <summary>
        /// Checks if a user is in a role.
        /// </summary>
        /// <param name="user">The user to check</param>
        /// <param name="roleName">The rolename to check</param>
        /// <returns>True if the user is in this role</returns>
        bool UserIsInRole(LogiszUser user, string roleName);

        /// <summary>
        /// Checks if the current user contains the role
        /// </summary>
        /// <param name="roleName">The rolename to check</param>
        /// <returns>True if this user is in this role</returns>
        bool UserIsInRole(string roleName);


        /// <summary>
        /// Checks if the user is a developer
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        bool UserIsDeveloper(LogiszUser user);

        /// <summary>
        /// Checks if the user is a developer
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        bool UserIsAdmin(LogiszUser user);


        /// <summary>
        /// Gets all logisz developers
        /// </summary>
        /// <returns>List<LogiszUser> Developers!!</returns>
        List<LogiszUser> GetDevelopers();


        /// <summary>
        /// Gets all users containing a specific role
        /// </summary>
        /// <param name="roleName">Name of the role as string, this is not case sensitive</param>
        /// <returns>LogiszUser</returns>
        List<LogiszUser> GetUsersInRole(string roleName, bool getProfileAswell = false);


        /// <summary>
        /// Creates a new sitefinity role, returns true if it already exists.
        /// </summary>
        /// <param name="roleName">The name of the role</param>
        /// <param name="roleManager">Optional role manager.</param>
        /// <returns>Success, true or false</returns>
        bool CreateRole(string roleName, RoleManager roleManager = null);

        #endregion

    }
}
