﻿
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.Extensions.Security.Models;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using Telerik.Sitefinity.Configuration;
using Telerik.Sitefinity.Security;
using Telerik.Sitefinity.Security.Claims;
using Telerik.Sitefinity.Security.Model;

namespace SitefinityWebApp.Logisz.Core.Extensions.Security
{
    /// <summary>
    /// Provides a custom logiszUserManager class which can obtain User and Profile easily.
    /// </summary>
    public sealed class LogiszUserManager : ILogiszUserManager
    {
        #region Properties & Attributes


        /// <summary>
        /// Default sitefinity UserManager instance
        /// </summary>
        public UserManager userManager { get { return UserManager.GetManager(); }  }

        /// <summary>
        /// Default sitefinity UserProfileManager instance
        /// </summary>
        public UserProfileManager userProfileManager { get { return UserProfileManager.GetManager(); } }

        /// <summary>
        /// Private role manager
        /// </summary>
        private RoleManager roleManager { get { return RoleManager.GetManager(SecurityConstants.ApplicationRolesProviderName); } }

        /// <summary>
        /// Private config file
        /// </summary>
        private LogiszConfig config { get { return Config.Get<LogiszConfig>(); } }

        /// <summary>
        /// Private logger
        /// </summary>
        //private ILogiszLogger logger { get { return LogiszDependencyContainer.GetInstance<ILogiszLogger>(); } }
        private readonly ILogiszLogger logger;

        #endregion

        #region Constructor

        /// <summary>
        /// Private initializer to avoid multiple instances
        /// </summary>
        private LogiszUserManager(ILogiszLogger logiszLogger)
        {
            this.logger = logiszLogger;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Gets the current user and profile object as LogiszUser
        /// </summary>
        /// <returns>LogiszUser object</returns>
        public LogiszUser GetLoggedOnUser()
        {
            SitefinityIdentity id = GetCurrentIdentity();
            LogiszUser currentUser = GetUserById(id.UserId);
            return currentUser;
        }


        /// <summary>
        /// Gets the current user and profile object as LogiszUser
        /// </summary>
        /// <returns>LogiszUser object</returns>
        public LogiszUser GetUserById(Guid id)
        {
            User user = PrivateGetUserById(id);
            SitefinityProfile profile = GetUserProfile(user);

            //Auto initialize
            LogiszUser currentUser = new LogiszUser(user, profile, this);

            return currentUser;
        }


        /// <summary>
        /// Checks if a user is in a role.
        /// </summary>
        /// <param name="user">The user to check</param>
        /// <param name="roleName">The rolename to check</param>
        /// <returns>True if the user is in this role</returns>
        public bool UserIsInRole(LogiszUser user, string roleName)
        {
            //Validate role
            if (!roleManager.RoleExists(roleName))
                return false;

            //Check if user object is empty or not
            if (!user.HasUser)
                return false;

            return roleManager.IsUserInRole(user.User.Id, roleName);

        }

        /// <summary>
        /// Checks if the current user contains the role
        /// </summary>
        /// <param name="roleName">The rolename to check</param>
        /// <returns>True if this user is in this role</returns>
        public bool UserIsInRole(string roleName)
        {
            return UserIsInRole(GetLoggedOnUser(), roleName);
        }


        /// <summary>
        /// Checks if the user is a developer
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public bool UserIsDeveloper(LogiszUser user)
        {
            string developerRole = config.Core.DeveloperRoleName;
            return UserIsInRole(user, developerRole);
        }


        /// <summary>
        /// Checks if the user is a developer
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public bool UserIsAdmin(LogiszUser user)
        {
            string adminRoleName = "Administrators";
            return UserIsInRole(user, adminRoleName);
        }


        /// <summary>
        /// Gets all logisz developers
        /// </summary>
        /// <returns>List<LogiszUser> Developers!!</returns>
        public List<LogiszUser> GetDevelopers()
        {
            return GetUsersInRole(config.Core.DeveloperRoleName, true);
        }


        /// <summary>
        /// Gets all users containing a specific role
        /// </summary>
        /// <param name="roleName">Name of the role as string, this is not case sensitive</param>
        /// <returns>LogiszUser</returns>
        public List<LogiszUser> GetUsersInRole(string roleName, bool getProfileAswell = false)
        {
            List<LogiszUser> result = new List<LogiszUser>();

            //Validate role
            if (!roleManager.RoleExists(roleName))
                return result;

            Role role = roleManager.GetRole(roleName);

            List<User> usersInRole = roleManager.GetUsersInRole(role).ToList();

            //Loop users to cast them
            foreach(User user in usersInRole)
            {
                SitefinityProfile profile = null;
                if(getProfileAswell)
                {
                    //Get profile
                    profile =  GetUserProfile(user);
                }

                LogiszUser cast = new LogiszUser(user, profile, this);
                result.Add(cast);
            }

            return result;
        }


        /// <summary>
        /// Creates a new sitefinity role, returns true if it already exists.
        /// </summary>
        /// <param name="roleName">The name of the role</param>
        /// <param name="roleManager">Optional role manager.</param>
        /// <returns>Success, true or false</returns>
        public bool CreateRole(string roleName, RoleManager roleManager = null)
        {
            try
            {
                //Make sure it is not null.
                roleManager = roleManager ?? RoleManager.GetManager(SecurityConstants.ApplicationRolesProviderName);
                bool roleExists = roleManager.RoleExists(roleName);

                //Role does not exist
                if (!roleExists)
                {
                    roleManager.CreateRole(roleName);
                    roleManager.SaveChanges();
                }

                return true;
            }
            catch (Exception e)
            {
                logger.LogException("LogiszUserManager: failed to create user role " + roleName + " due an error: ", e);
                return false;
            }
        }


        #endregion

        #region Private methods


        /// <summary>
        /// Gets the user object by ID, returns NULL if user is not found.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private User PrivateGetUserById(Guid id)
        {
            if (id == null)
                return null;
            if (id == Guid.Empty)
                return null;

            UserManager userManager = UserManager.GetManager();
            User user = userManager.GetUser(id);

            return user;
        }


        /// <summary>
        /// get Identity from current logged in User
        /// </summary>
        /// <returns></returns>
        private SitefinityIdentity GetCurrentIdentity()
        {
            SitefinityIdentity identity = ClaimsManager.GetCurrentIdentity();

            return identity;
        }


        /// <summary>
        /// Get user profile
        /// </summary>
        /// <param name="user">The sitefinity user object</param>
        /// <returns>SitefinityProfile</returns>
        private SitefinityProfile GetUserProfile(User user)
        {
            SitefinityProfile profile = null;
            if (user != null)
            {
                var profileManager = UserProfileManager.GetManager();
                profile = profileManager.GetUserProfile<SitefinityProfile>(user);
            }

            return profile;
        }

        #endregion
    }
}