﻿using System;
using System.Collections.Generic;

namespace SitefinityWebApp.Logisz.Core.System.Logger
{
    public interface ILogiszLogger
    {
        void InitializeLogger();
        void Log(string toLog, string logFileName = null);
        void LogException(string moduleName, Exception e);
        void LogException(string message);


        /// <summary>
        /// Get the logs
        /// </summary>
        /// <returns></returns>
        List<Log> GetLogs();

        /// <summary>
        /// Gets a log by file name, if null or empty, returns default log
        /// </summary>
        /// <param name="logFileName">The file name of the log without extension and path</param>
        /// <returns><see cref="Log"/></returns>
        Log GetLogByFileName(string logFileName);

        /// <summary>
        /// Gets the default log
        /// </summary>
        /// <returns><see cref="Log"/></returns>
        Log GetDefaultLog();

    }
}