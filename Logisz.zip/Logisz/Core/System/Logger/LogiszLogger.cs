﻿

using SitefinityWebApp.Logisz.Core.Utilities.APIS;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SitefinityWebApp.Logisz.Core.System.Logger
{
    /// <summary>
    /// Logisz logger gives the ability to log.
    /// </summary>
    public sealed class LogiszLogger : ILogiszLogger
    {
        private static bool initialized = false;

        /// <summary>
        /// All stored logfiles
        /// </summary>
        private static List<Log> logs { get; set; }

        /// <summary>
        /// Indicates if the files are already registered
        /// </summary>
        private static bool Registered = false;
        public static readonly string LogFileExtension = ".txt";
        public static readonly string LogFilePath = "/App_Data/Sitefinity/Logs/";
        public static readonly string DefaultLogFileName = "LogiszCoreLog";
        public static readonly string ExceptionLogFileName = "LogiszExceptionLog";

        #region Initialization

        private LogiszLogger()
        {
            /* ATTENTION ! THE LOGGER CANNOT INHARIT FROM ANY OTHER MANAGER OR CLASS BECAUSE THIS
             * CLASSES ARE USING THE LOGGER. IT'S NOT RECOMMANDED TO LET THE LOGGER USE OTHER MANAGERS
             * THIS CAN CAUSE INFINATE LOOPS IN THE LOGISZ DEPENDENCY INJECTOR.*/
        }

        /// <summary>
        /// Initializes the logger, this is done ONCE.
        /// </summary>
        public void InitializeLogger()
        {
            if (initialized)
                return;

            //Register the log file
            RegisterSystemLogs();

            initialized = true;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Writes a single line
        /// </summary>
        /// <param name="toLog"></param>
        public void Log(string toLog, string logFileName = null)
        {
            Log log = GetLogByFileName(logFileName);

            if (log == null)
                return;
            if (!log.isRegistered)
                return;

            //Write line
            using (var tw = new StreamWriter(log.GetFullPath(), true))
            {
                string dateTime = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
                tw.WriteLine(dateTime + " - " + toLog);
            }

            //Also write to default log
            if(logFileName != null)
                Log(toLog);
        }


        /// <summary>
        /// Logs an exception in the Logisz log
        /// </summary>
        /// <param name="moduleName">Name of the module where the error occured</param>
        /// <param name="e">The exception</param>
        public void LogException(string moduleName, Exception e)
        {
            Log(String.Format("An <span class=''>error</span> occured in the {0} module:<br/>{1}, {2}, {3}", moduleName, e.Message, e.InnerException, e.StackTrace), ExceptionLogFileName);
        }

        /// <summary>
        /// Logs an exception in the Logisz log
        /// </summary>
        /// <param name="moduleName">Name of the module where the error occured</param>
        public void LogException(string message)
        {
            Log(message, ExceptionLogFileName);
        }

        /// <summary>
        /// Registers a single log
        /// </summary>
        /// <param name="fileName">Filename of thel log</param>
        /// <param name="friendlyName">Friendly log name</param>
        /// <param name="clearOnInit">Clear on init</param>
        public void RegisterLog(string fileName, string friendlyName, bool clearOnInit = true)
        {
            //Register the log
            Log registeredLog = new Log(fileName, friendlyName, clearOnInit).Register();
            logs.Add(registeredLog);
        }


        /// <summary>
        /// Get the logs
        /// </summary>
        /// <returns></returns>
        public List<Log> GetLogs()
        {
            return logs;
        }


        /// <summary>
        /// Gets a log by file name, if null or empty, returns default log
        /// </summary>
        /// <param name="logFileName">The file name of the log without extension and path</param>
        /// <returns><see cref="Log"/></returns>
        public Log GetLogByFileName(string logFileName)
        {
            if (!Registered)
                RegisterSystemLogs();

            Log log;

            if (String.IsNullOrEmpty(logFileName))
                return GetDefaultLog();

            Log tryGetLog = logs.FirstOrDefault(lo => lo.FileName.ToLower() == logFileName.ToLower());
            log = tryGetLog ?? GetDefaultLog();

            return log;
        }


        /// <summary>
        /// Gets the default log
        /// </summary>
        /// <returns><see cref="Log"/></returns>
        public Log GetDefaultLog()
        {
            return GetLogByFileName(DefaultLogFileName);
        }


        #endregion

        #region Private methods


        /// <summary>
        /// Register systemlogs in the logs attribute. These files are not yet registered
        /// </summary>
        private void RegisterSystemLogs()
        {
            if (Registered)
                return;

            Registered = true;
            logs = new List<Log>();
            RegisterLog("LogiszCoreLog", "Core log");
            RegisterLog("LogiszExceptionLog", "Exceptions", false);
            RegisterLog(LogiszAPIBase.LOGGER_API_LOGNAME, "API log");
        }


        #endregion
    }
}