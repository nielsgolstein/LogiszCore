﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.System.Logger
{
    public class Log
    {
        public string FileName { get; private set; }
        public bool isRegistered { get; private set; }

        /// <summary>
        /// Do we need to clear this log on initialize
        /// </summary>
        public bool clearOnInit { get; private set; }

        /// <summary>
        /// Incidates if we need to write the log at the default log aswell
        /// </summary>
        public bool writeDefaultLog { get; private set; }
        public string FriendlyName { get; private set; }

        /// <summary>
        /// Create a new log. This is NOT automatically registered in the system.
        /// </summary>
        /// <param name="fileName">Filename of the log</param>
        /// <param name="friendlyName">The friendly name of the log used in the debugger, optional. If empty, the fileName is used.</param>
        /// <param name="clearOnInit">Determines if this logfile needs to be creared on initialize</param>
        public Log(string fileName, string friendlyName = null, bool clearOnInit = true)
        {
            this.FileName = fileName;
            this.FriendlyName = friendlyName ?? fileName;
            this.clearOnInit = clearOnInit;
            CheckIfRegistered();
        }


        /// <summary>
        /// Checks if this config is registered
        /// </summary>
        private void CheckIfRegistered()
        {
            if (File.Exists(BuildPath()))
                this.isRegistered = true;
        }

        /// <summary>
        /// Registers the log file
        /// </summary>
        public Log Register()
        {
            //Register the logfile
            if (!File.Exists(BuildPath()))
            {
                File.Create(BuildPath()).Dispose();
            } else
            {
                TryClear();
            }

            isRegistered = true;
            return this;
        }

        /// <summary>
        /// Try to clear log if we have to
        /// </summary>
        private void TryClear()
        {
            if (clearOnInit)
            {
                //Write line
                File.WriteAllText(GetFullPath(), String.Empty);
            }
        }

        /// <summary>
        /// Gets the full path
        /// </summary>
        /// <returns>Full path</returns>
        private string BuildPath()
        {
            //return HttpContext.Current.Server.MapPath("~") + LogiszLogger.LogFilePath + FileName + LogiszLogger.LogFileExtension;
            return "C:/Internet/root/www/Codebase/www/Dev/" + LogiszLogger.LogFilePath + FileName + LogiszLogger.LogFileExtension;
        }


        /// <summary>
        /// Gets the full path
        /// </summary>
        /// <returns>Full path</returns>
        public string GetFullPath()
        {
            return BuildPath();
        }

        /// <summary>
        /// Gets the lines of the log
        /// </summary>
        /// <returns>List of lines</returns>
        public List<string> GetLogLines()
        {
            List<string> lines = new List<string>();
            int counter = 0;
            string line;

            // Read the file and display it line by line.  
            StreamReader file = new StreamReader(GetFullPath());
            while ((line = file.ReadLine()) != null)
            {
                string theLine = line;

                lines.Add(line);
                counter++;
            }

            file.Close();

            return lines;
        }
    }
}