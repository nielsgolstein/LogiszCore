﻿using SitefinityWebApp.Logisz.Core.Inharitances;
using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Reflection;
using System.Collections.Generic;

namespace SitefinityWebApp.Logisz.Core.System.Plugins.Initialization
{
    public class LogiszPluginInitializer : ILogiszPluginInitializer
    {
        private const string initializationMethod = "BaseInitialize";
        private readonly IAutoInitializer _autoInitializer;
        private readonly ILogiszLogger _logiszLogger;

        private LogiszPluginInitializer(IAutoInitializer autoInitializer, ILogiszLogger logiszLogger)
        {
            this._autoInitializer = autoInitializer;
            this._logiszLogger = logiszLogger;
        }

        /// <summary>
        /// Initializes all registered plugins using the <see cref="LogiszPlugin"/> class
        /// </summary>
        public void InitializePlugins()
        {
            _logiszLogger.Log("PluginInitializer: Start Initialize plugins");

            List<Type> pluginsToInitialize = _autoInitializer.GetOrderedTypesToInitialize<LogiszPlugin>();
            
            //Initialize the plugins
            foreach (Type type in pluginsToInitialize)
            {
                try
                {
                    Object instance = _autoInitializer.GetInstanceOfType(type);
                    Type instanceType = instance.GetType();

                    //Cast to LogiszPlugin
                    LogiszPlugin plugin = (LogiszPlugin)instance;
                    plugin.AutoRegisterModule(instanceType);

                    _logiszLogger.Log("PluginInitializer: Succesfully initialized " + type.Name);
                }
                catch (Exception e)
                {
                    _logiszLogger.LogException("PluginInitializer", e);
                }
            }

            _logiszLogger.Log("PluginInitializer: Finished Initialize plugins");
        }
    }
}