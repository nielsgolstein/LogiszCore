﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SitefinityWebApp.Logisz.Core.System.Plugins.Initialization
{
    public interface ILogiszPluginInitializer
    {
        /// <summary>
        /// Delegation method to execute plugin initialization
        /// </summary>
        void InitializePlugins();
    }
}
