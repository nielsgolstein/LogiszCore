﻿using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.Inharitances;
using SitefinityWebApp.Logisz.Core.Modules.Debugger;
using SitefinityWebApp.Logisz.Core.System.Dependency;
using System;
using System.Reflection;

namespace SitefinityWebApp.Logisz.Core.System.Plugins
{
    /// <summary>
    /// Abstract Lgszmodule class, force inharit
    /// </summary>
    public abstract class LogiszPlugin : LogiszAutoValidationModel
    {
        #region Attributes

        /// <summary>
        /// Name of the module
        /// </summary>
        public string ModuleName { get; private set; }

        /// <summary>
        /// Name of the module -> Friendly :)
        /// </summary>
        public string FriendlyModuleName;

        /// <summary>
        /// Path to the files of the module
        /// </summary>
        public string ModulePath;

        /// <summary>
        /// The type of the module to auto define the name and path
        /// </summary>
        private Type ModuleType { get; set; }

        /// <summary>
        /// Config for this module
        /// </summary>
        public LogiszModuleConfigElement Config { get {
            if(FuncToGetScopedConfig == null)
            {
                throw new Exception("FuncToGetScopedConfig in LogiszModule is not initialized, use method DefineModuleScopedConfig inside the Initialize method to fix this problem.");
            }
            return FuncToGetScopedConfig();
        } }

        /// <summary>
        /// Determines if this module has a scoped config.
        /// </summary>
        public bool HasScopedConfig { get { return FuncToGetScopedConfig != null; } }

        /// <summary>
        /// Custom func to get the specific config for this module.
        /// </summary>
        private Func<LogiszModuleConfigElement> FuncToGetScopedConfig { get; set; }


        private readonly ILogiszDebugger Debugger;
        private readonly ILogiszConfigManager _logiszConfigManager;

        /// <summary>
        /// The global config.
        /// </summary>
        public LogiszConfig globalConfig { get { return _logiszConfigManager.GetConfig(); } }

        /// <summary>
        /// Returns true if this module model is active and valid.
        /// </summary>
        public bool IsActive { get { return ValidateActivity(); } }


        #endregion

        #region Constructor

        protected LogiszPlugin() : base() {
            this.Debugger = LogiszDependencyContainer.Resolve<ILogiszDebugger>();
            this._logiszConfigManager = LogiszDependencyContainer.Resolve<ILogiszConfigManager>();
        }

        #endregion

        /// <summary>
        /// Registers itsself in the <see cref="LogiszPluginBase"/>
        /// </summary>
        public void AutoRegisterModule(Type pluginClassType)
        {
            //Define the type of the plugin
            DefineModuleType(pluginClassType);

            LogiszPluginData dataAttribute = pluginClassType.GetCustomAttribute<LogiszPluginData>();
            if(dataAttribute != null)
            {
                FriendlyModuleName = dataAttribute.FriendlyName;
            }

            //Set name if empty
            if (String.IsNullOrEmpty(ModuleName))
                ModuleName = nameof(pluginClassType);

            //Register it to the base
            LogiszPluginBase.RegisterModule(this);
            this.Initialize();
        }

        /// <summary>
        /// Abstract initialization method 
        /// </summary>
        public abstract void Initialize();

        #region Getters & Setters


        /// <summary>
        /// Gets the defined module type
        /// </summary>
        /// <returns><see cref="Type"/> or NULL if type is not defined.</returns>
        public Type GetModuleType()
        {
            return this.ModuleType;
        }


        /// <summary>
        /// Defines the type of the module to auto load the path and name
        /// </summary>
        /// <typeparam name="T">Type of the module</typeparam>
        private void DefineModuleType<T>() where T : LogiszPlugin
        {
            Type moduleType = typeof(T);
            DefineModuleType(moduleType);
        }


        /// <summary>
        /// Defines the type of the module to auto load the path and name
        /// </summary>
        /// <param name="moduleType"></param>
        private void DefineModuleType(Type moduleType)
        {
            this.ModuleType = moduleType;
            this.ModuleName = moduleType.Name;
            this.ModulePath = globalConfig.Core.DefaultModulePath;
        }

        /// <summary>
        /// Scope the config to the config which contains debugger data. This is done with Func because
        /// we want to receife the up-to-date config file and not a pre-stored data element which can be 
        /// corrupted durring time.
        /// </summary>
        /// <param name="funcToGetConfig">Func to receive config</param>
        protected void DefineModuleScopedConfig(Func<LogiszModuleConfigElement> funcToGetConfig)
        {
            this.FuncToGetScopedConfig = funcToGetConfig;
        }

        #endregion

        #region Debug methods

        /// <summary>
        /// Tries to enable the debugger if the module is valid
        /// </summary>
        public void Debug()
        {
            if(IsValidForDebugging())
            {
                string modName = String.IsNullOrEmpty(this.FriendlyModuleName) ? this.ModuleName : this.FriendlyModuleName;
                Debugger.TryEnableDebugger(this.ModuleName, this.Config);
            }
        }

        /// <summary>
        /// Tries to enable the debugger if the module is valid
        /// </summary>
        /// <typeparam name="T">Type of data model</typeparam>
        /// <param name="data">The data model</param>
        public void Debug<T>(T data)
        {
            if (IsValidForDebugging())
            {
                Debugger.TryEnableDebugger(this, data);
            }   
        }

        #endregion

        #region Validation methods

        /// <summary>
        /// Check if this module is valid for debug
        /// </summary>
        /// <returns>True if valid, false if invalid</returns>
        private bool IsValidForDebugging()
        {
            if (Config == null)
                return false;

            if (!IsValid)
                return false;

            if (string.IsNullOrEmpty(ModulePath))
                return false;

            if (!HasScopedConfig)
                return false;
            return true;
        }

        /// <summary>
        /// Self-validation
        /// </summary>
        protected override bool AutoValidate()
        {
            if (String.IsNullOrEmpty(ModuleName))
                return SetModelInvalid("Modulename is not set. This can be done by calling setting the attribute ModuleName.");

            if (ModuleType == null)
                return SetModelInvalid("Type of the module is not defined. This can be done by calling the method DefineModuleType.");

            return true;
        }

        /// <summary>
        /// Check if this module is valid and active
        /// </summary>
        /// <returns>True if active</returns>
        private bool ValidateActivity()
        {
            if (!IsValid)
                return false;


            if (Config != null)
                if (!Config.Active)
                    return false;

            return true;
        }

        #endregion
    }
}