﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.System.Plugins
{
    public class LogiszPluginData : Attribute
    {
        public string FriendlyName { get; set; }
        public Func<LogiszModuleConfigElement> ScopedConfig { get; set; }

        public LogiszPluginData(string friendlyName)
        {
            this.FriendlyName = friendlyName;
        }

       
    }
}