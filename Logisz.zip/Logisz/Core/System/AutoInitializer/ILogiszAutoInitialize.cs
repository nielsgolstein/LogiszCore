﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SitefinityWebApp.Logisz.Core.System.AutoInitializer
{
    /// <summary>
    /// Logisz auto initializer makes sure the system initializes.
    /// </summary>
    public interface ILogiszAutoInitialize
    {

        /// <summary>
        /// Automatically initializes
        /// </summary>
        void AutoInitialize();
    }
}
