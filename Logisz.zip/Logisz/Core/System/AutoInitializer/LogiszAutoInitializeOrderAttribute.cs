﻿using System;

namespace SitefinityWebApp.Logisz.Core.System.AutoInitializer
{
    /// <summary>
    /// Auto initializes this module using <see cref="InitializeInterfaces"/>, ordered by the loadOrder attribute (low to high ordered)
    /// </summary>
    public sealed class LogiszAutoInitializeOrderAttribute : Attribute
    {
        /// <summary>
        /// Automatically sorts loadorder asc.
        /// </summary>
        public LogiszAutoInitializeOrderValues order { get; set; }

        /// <summary>
        /// If we want to sort even more specific, we use the second parameter
        /// </summary>
        public int secondaryOrder { get; set; }

        /// <summary>
        /// Auto initializes this module using <see cref="InitializeInterfaces"/>, ordered by the loadOrder attribute (low to high ordered)
        /// </summary>
        /// <param name="orderValue">The order of initialization</param>
        public LogiszAutoInitializeOrderAttribute(LogiszAutoInitializeOrderValues orderValue, int secondaryOrder = 1000)
        {
            this.order = orderValue;
            this.secondaryOrder = secondaryOrder;
        }

        public LogiszAutoInitializeOrderAttribute(int secondaryOrder)
        {
            this.order = LogiszAutoInitializeOrderValues.LOGISZ_PLUGIN_INITIALIZE;
            this.secondaryOrder = secondaryOrder;
        }

    }
}