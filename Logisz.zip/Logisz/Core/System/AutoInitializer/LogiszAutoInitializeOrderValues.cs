﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.System.AutoInitializer
{
    /// <summary>
    /// Represents a specific order for loading the auto initializer. This initializer will order
    /// the int values ascend.
    /// </summary>
    public enum LogiszAutoInitializeOrderValues
    {
        LOGISZ_BEFORE_CORE_INITIALIZE = 1,
        LOGISZ_CORE_INITIALIZE = 2,
        LOGISZ_PLUGIN_INITIALIZE = 3
    }
}