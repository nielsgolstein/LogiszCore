﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace SitefinityWebApp.Logisz.Core.System.AutoInitializer
{
    /// <summary>
    /// Provide dependency injection
    /// </summary>
    public interface IAutoInitializer
    {
        /// <summary>
        /// Auto initialize classes with interface
        /// </summary>
        /// <typeparam name="T">The interface which needs to be initialized</typeparam>
        /// <param name="methodName">The method of the interface to be executed</param>
        List<Type> GetOrderedTypesToInitialize<T>();

        /// <summary>
        /// Delegation
        /// </summary>
        void InitializeCore();

        /// <summary>
        /// Receife method info from a specific type and method.
        /// </summary>
        /// <param name="type">The type</param>
        /// <param name="methodToInitialize">The method name</param>
        /// <returns></returns>
        MethodInfo GetMethodInfo(Type type, string methodToInitialize);

        /// <summary>
        /// Gets a instance of a type using the dependency container
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        Object GetInstanceOfType(Type type);
    }
}