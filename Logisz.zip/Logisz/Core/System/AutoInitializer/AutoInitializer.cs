﻿using SitefinityWebApp.Logisz.Core.System.Dependency;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace SitefinityWebApp.Logisz.Core.System.AutoInitializer
{
    public class AutoInitializer : IAutoInitializer
    {
        private readonly Type autoInitializeType = typeof(ILogiszAutoInitialize);
        private readonly Type autoInitializeOrderAttributeType = typeof(LogiszAutoInitializeOrderAttribute);
        private readonly string autoInitializeMethodName = "AutoInitialize";
        private readonly string assemblyFullnamePart = "SitefinityWebApp,";
        private readonly int defaultOrderValue = 1000;
        private readonly ILogiszLogger _logiszLogger;

        private AutoInitializer(ILogiszLogger logiszLogger)
        {
            this._logiszLogger = logiszLogger;
        }

        /// <summary>
        /// Delegation method for InitializeInterfaceOrClass<ILogiszAutoInitialize>();
        /// </summary>
        public void InitializeCore()
        {
            List<Type> typesToInitialize = GetOrderedTypesToInitialize<ILogiszAutoInitialize>();
            InvokeAutoInitializeInterfaces(typesToInitialize, autoInitializeMethodName);
        }

        /// <summary>
        /// Auto initialize classes with interface
        /// </summary>
        /// <typeparam name="T">The interface which needs to be initialized</typeparam>
        /// <param name="methodName">The method of the interface to be executed</param>
        public List<Type> GetOrderedTypesToInitialize<T>()
        {
            List<Type> classesWithType = GetClassesWithInterface<T>();
            Dictionary<Type, int[]> toInit = GetClassesWithInitializationOrder(classesWithType);

            #region Order & Log

            ///Order based on primair and secundair order
            List<KeyValuePair<Type, int[]>> initializationOrder = toInit
                                            .OrderBy(q => q.Value[1])
                                            .OrderBy(q => q.Value[0]).ToList();

            _logiszLogger.Log("AutoInitializer: Initializing following interfaces by order: ");
            _logiszLogger.Log("AutoInitializer: -------------------------------------------------------------");
            foreach (KeyValuePair<Type, int[]> pair in initializationOrder)
            {
                //Simply log order
                _logiszLogger.Log("AutoInitializer: " + pair.Key.Name + " primair: " + pair.Value[0] + "  secundair: " + pair.Value[1]);
            }
            _logiszLogger.Log("AutoInitializer: -------------------------------------------------------------");

            #endregion

            //Grab keys
            List<Type> typesToInitialize = initializationOrder
                                            .Select(q => q.Key).ToList();
            return typesToInitialize;
        }

        /// <summary>
        /// Invoke the interfaces
        /// </summary>
        /// <param name="typesToInitialize">The types to invoke</param>
        /// <param name="methodToInitialize">Method name</param>
        private void InvokeAutoInitializeInterfaces(List<Type> typesToInitialize, string methodToInitialize)
        {
            //Initialize the types
            foreach (Type type in typesToInitialize)
            {
                try
                {
                    Object instance = GetInstanceOfType(type);
                    MethodInfo method = GetMethodInfo(type, methodToInitialize);
                    if(method == null)
                    {
                        _logiszLogger.Log("AutoInitializer: Method not found: " + methodToInitialize);
                        continue;
                    }

                    //Execute method
                    method.Invoke(instance, null);

                    _logiszLogger.Log("AutoInitializer: Succesfully initialized " + type.Name);
                }
                catch (Exception e)
                {
                    _logiszLogger.LogException("Autoinitializer", e);
                }
            }
        }

        /// <summary>
        /// Getting info of a method to execute
        /// </summary>
        /// <param name="type">Type of interface</param>
        /// <param name="methodToInitialize">Methodname</param>
        /// <returns></returns>
        public MethodInfo GetMethodInfo(Type type, string methodToInitialize)
        {
            //Get the interface method
            MethodInfo method = type.GetInterface(autoInitializeType.Name)
                                 .GetMethod(methodToInitialize);

            return method;
        }

        /// <summary>
        /// Getting an instance of a type from the dependency container
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public Object GetInstanceOfType(Type type)
        {
            //Get instance
            LogiszDependencyRegistration DRegistration = LogiszDependencyContainer.GetRegistrationByClassType(type);
            object instance = null;

            //If no dependency found, we are creating one.//
            if (DRegistration == null)
            {
                instance = LogiszDependencyContainer.Resolve(type);
            }
            else
            {
                //Get dependency
                instance = LogiszDependencyContainer.Resolve(DRegistration.InterfaceToResolve);
            }
            return instance;
        }

        /// <summary>
        /// Gets all order attributes of the to initialize classes
        /// </summary>
        /// <param name="classesWithType">The classes with the interface type</param>
        /// <returns>Dictionary<Type, int[]></returns>
        private Dictionary<Type, int[]> GetClassesWithInitializationOrder(List<Type> classesWithType)
        {
            Dictionary<Type, int[]> toInit = new Dictionary<Type, int[]>();

            //Loop all classes
            foreach (Type t in classesWithType)
            {
                //Skip if is a instance
                if (!t.IsClass || t.IsInterface)
                    continue;

                //Get the attribute, so we can obtain the order.
                int defaultOrderValue = this.defaultOrderValue;
                int primairOrder = defaultOrderValue;
                int secundairOrder = defaultOrderValue;

                LogiszAutoInitializeOrderAttribute logiszAutoInitializeOrderAttribute = t.GetCustomAttribute<LogiszAutoInitializeOrderAttribute>();
                if (logiszAutoInitializeOrderAttribute != null)
                {
                    primairOrder = (int)logiszAutoInitializeOrderAttribute.order;
                    secundairOrder = logiszAutoInitializeOrderAttribute.secondaryOrder;
                }


                //Add to list...
                toInit.Add(t, new int[2] { primairOrder, secundairOrder });
            }

            return toInit;
        }

        /// <summary>
        /// Gets all classes containing the interface
        /// </summary>
        /// <typeparam name="INTERFACE">The interface</typeparam>
        /// <returns>List<Type></returns>
        protected List<Type> GetClassesWithInterface<INTERFACE>()
        {
            Type interfaceType = typeof(INTERFACE);

            //Get sitefinitywebapp assemblies
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            assemblies = assemblies.Where(a => a.FullName.Contains(assemblyFullnamePart)).ToArray();

            //Loop them to find the intilizertype
            List<Type> classesWithType = assemblies.SelectMany(s => s.GetTypes())
                .Where(p => p.ImplementsInterface(interfaceType))
                .ToList();

            if(classesWithType.Count != 0)
            {
                return classesWithType;
            }

            classesWithType = assemblies.SelectMany(s => s.GetTypes())
                .Where(p => p.BaseType == typeof(INTERFACE))
                .ToList();

            return classesWithType;
        }


    }
}