﻿using SitefinityWebApp.Logisz.Core.Configurations.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.System
{
    public static class Constants
    {
        /// <summary>
        /// Viewname of the quick debugger
        /// </summary>
        public const string QUICK_DEBUG_VIEWNAME = "QuickDebug";

        /// <summary>
        /// Viewpath of the quick debugger
        /// </summary>
        public const string QUICK_DEBUG_VIEWPATH = "/Logisz/Core/Modules/Debugger/Views/LogiszCore/";

        /// <summary>
        /// Friendly name of the quick debugger
        /// </summary>
        public const string QUICK_DEBUG_FRIENDLYNAME = "Quick debug";

        /// <summary>
        /// The version of the LogiszCore.
        /// </summary>
        public const string VERSION = "2.0.3";
    }
}