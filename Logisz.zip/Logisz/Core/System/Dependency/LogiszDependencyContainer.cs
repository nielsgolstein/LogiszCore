﻿using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Events;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using SitefinityWebApp.Logisz.Core.Modules.Debugger;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.Exceptions;
using SitefinityWebApp.Logisz.Core.System.Localization;
using SitefinityWebApp.Logisz.Core.System.Plugins.Initialization;

namespace SitefinityWebApp.Logisz.Core.System.Dependency
{
    /// <summary>
    /// Provides dependendy to our logisz core.
    /// </summary>
    public sealed class LogiszDependencyContainer
    {
        private static List<LogiszDependencyRegistration> registrations { get; set; }
        private static Dictionary<Type, object> instances { get; set; }
        private static bool registered;

        #region Public methods

        /// <summary>
        /// Registers dependencies
        /// </summary>
        public static void RegisterDependencies()
        {
            if (registered)
                return;

            LogiszDependencyContainer.Register<ILogiszLogger, LogiszLogger>(true);
            LogiszDependencyContainer.Register<ILogiszConfigManager, LogiszConfigManager>(true);
            LogiszDependencyContainer.Register<ILogiszEventManager, LogiszEventManager>(true);
            LogiszDependencyContainer.Register<ILogiszUserManager, LogiszUserManager>(true);
            LogiszDependencyContainer.Register<ILogiszDebugger, LogiszDebugger>(true);
            LogiszDependencyContainer.Register<IAutoInitializer, AutoInitializer.AutoInitializer>(true);
            LogiszDependencyContainer.Register<ILogiszPluginInitializer, LogiszPluginInitializer>(true);
            LogiszDependencyContainer.Register<ILogiszResourceManager, LogiszResourceManager>(true);
            //LogiszDependencyContainer.Register<ILogiszDataSynchronizer, LogiszDataSynchronizer>(true);

            //Singletons
            LogiszDependencyContainer.RegisterSingleton<ILogiszLogger, LogiszLogger>();
            LogiszDependencyContainer.RegisterSingleton<ILogiszConfigManager, LogiszConfigManager>();
            LogiszDependencyContainer.RegisterSingleton<ILogiszEventManager, LogiszEventManager>();
            LogiszDependencyContainer.RegisterSingleton<ILogiszUserManager, LogiszUserManager>();
            LogiszDependencyContainer.RegisterSingleton<ILogiszDebugger, LogiszDebugger>();
            LogiszDependencyContainer.RegisterSingleton<IAutoInitializer, AutoInitializer.AutoInitializer> ();
            LogiszDependencyContainer.RegisterSingleton<ILogiszPluginInitializer, LogiszPluginInitializer>();
            LogiszDependencyContainer.RegisterSingleton<ILogiszResourceManager, LogiszResourceManager>();
            //LogiszDependencyContainer.RegisterSingleton<ILogiszDataSynchronizer, LogiszDataSynchronizer>();


            registered = true;
        }

        /// <summary>
        /// Registers a new resolved type (interface, class)
        /// </summary>
        /// <typeparam name="TypeToResolve">The interface</typeparam>
        /// <typeparam name="ResolvedType">The class</typeparam>
        public static void Register<TypeToResolve, ResolvedType>(bool isSingleton = false) where ResolvedType : class
        {
            InitializeLists();

            registrations.Add(
                new LogiszDependencyRegistration(typeof(TypeToResolve), typeof(ResolvedType), isSingleton)
            );
        }

        /// <summary>
        /// Registers a singleton dependency
        /// </summary>
        /// <typeparam name="TypeToResolve"></typeparam>
        /// <typeparam name="ResolvedType"></typeparam>
        public static void RegisterSingleton<TypeToResolve, ResolvedType>() where ResolvedType : class
        {
            //Make sure list is filled
            if (instances == null)
                instances = new Dictionary<Type, object>();

            //Temp object
            object i;

            //Check existance, if it is already registered, we do nothing.
            if (!instances.TryGetValue(typeof(TypeToResolve), out i))
            {
                //Resolve and store the instance
                TypeToResolve instance = CreateInstanceOf<TypeToResolve>(typeof(ResolvedType));
                instances.Add(typeof(TypeToResolve), instance);
            }

        }


        /// <summary>
        /// Gets a item based on it's dependency interface (ResolvedType)
        /// </summary>
        /// <typeparam name="TResolvedType">The interface which holds the dependency</typeparam>
        /// <returns>Class which is connected to our interface</returns>
        public static TResolvedType Resolve<TResolvedType>()
        {
            return (TResolvedType)Resolve(typeof(TResolvedType));
        }


        /// <summary>
        /// (Overload) Gets a item based on it's dependency interface (ResolvedType)
        /// </summary>
        /// <param name="resolvedType">The interface which holds the dependency</param>
        /// <returns>Class which is connected to our interface</returns>
        public static object Resolve(Type resolvedType)
        {
            if(resolvedType.IsClass)
                return CreateInstanceOf<object>(resolvedType);

            InitializeLists();

            #region try to get singleton instance
            object resolvedObject = GetInstance(resolvedType);
            if (resolvedObject != null)
                return resolvedObject;
            #endregion

            //Get registration
            LogiszDependencyRegistration toResolveDependency = registrations.FirstOrDefault(q => q.InterfaceToResolve == resolvedType);

            //Check existance
            if (toResolveDependency != null)
            {
                object resolvedItem = CreateInstanceOf<object>(toResolveDependency.ResolvedType);

                //If this is registered as a singleton, we add it to our singletons list to avoid having another instance
                if (toResolveDependency.IsSingleton)
                    instances.Add(toResolveDependency.InterfaceToResolve, resolvedItem);

                return resolvedItem;
            }

            throw new LogiszDependencyNotRegisteredException("LogiszDependencyContainer");
        }

        #endregion

        #region Getters

        /// <summary>
        /// Gets the registration based on the class
        /// </summary>
        /// <param name="resolvedType">Type of class</param>
        /// <returns></returns>
        public static LogiszDependencyRegistration GetRegistrationByClassType(Type resolvedType)
        {
            return registrations.FirstOrDefault(q => q.ResolvedType == resolvedType);
        }

        /// <summary>
        /// Gets all registered dependencies
        /// </summary>
        /// <returns></returns>
        public static List<LogiszDependencyRegistration> GetRegistrations() {
            return registrations;
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Creating an instance of generic type
        /// </summary>
        /// <typeparam name="T">Generic type</typeparam>
        /// <returns>Instance of generic type</returns>
        private static TTypeToResolve CreateInstanceOf<TTypeToResolve>(Type resolvedType)
        {
            Type objectType = resolvedType;

            //Get all constructors
            //ConstructorInfo constructor = objectType.GetConstructors().FirstOrDefault();
            ConstructorInfo constructor = resolvedType.GetConstructors(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).FirstOrDefault();

            //Validate NULL
            if (constructor == null)
                throw new Exception("No constructor found to initialize.");

            //Get parameters to initialize the other dependencies of this class.
            List<object> parameterTypes = new List<object>();
            foreach (ParameterInfo param in constructor.GetParameters())
            {
                Type resolveType = param.ParameterType;
                object interfaceInstance = Resolve(resolveType);
                parameterTypes.Add(interfaceInstance);
            }

            //TTypeToResolve instance = (TTypeToResolve)Activator.CreateInstance(objectType, parameterTypes.ToArray(),);

            return (TTypeToResolve)constructor.Invoke(parameterTypes.ToArray());
        }

        /// <summary>
        /// Makes sure lists are not NULL
        /// </summary>
        private static void InitializeLists()
        {
            //Make sure list is filled
            if (registrations == null)
                registrations = new List<LogiszDependencyRegistration>();

            //Make sure list is filled
            if (instances == null)
                instances = new Dictionary<Type, object>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">Interface</typeparam>
        /// <returns></returns>
        private static TInterface GetInstance<TInterface>()
        {
            return (TInterface)GetInstance(typeof(TInterface));
        }


        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">Interface</typeparam>
        /// <returns></returns>
        private static object GetInstance(Type interfaceType)
        {
            InitializeLists();

            object instance;

            //Check existance
            instances.TryGetValue(interfaceType, out instance);

            return instance;
        }


        #endregion
    }
}