﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.System.Dependency
{
    public sealed class LogiszDependencyRegistration
    {
        public Type InterfaceToResolve { get; private set; }
        public Type ResolvedType { get; private set; }
        public bool IsSingleton { get; private set; }

        /// <summary>
        /// Single registration for a dependency
        /// </summary>
        /// <param name="interfaceToResolve">The interface which is connected to a class-type</param>
        /// <param name="resolvedType">Class type</param>
        /// <param name="isSingleton">Indicates if this can only have one instance</param>
        public LogiszDependencyRegistration(Type interfaceToResolve, Type resolvedType, bool isSingleton)
        {
            this.IsSingleton = isSingleton;
            this.ResolvedType = resolvedType;
            this.InterfaceToResolve = interfaceToResolve;
        }
    }
}