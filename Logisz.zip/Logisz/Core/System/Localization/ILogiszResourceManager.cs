﻿namespace SitefinityWebApp.Logisz.Core.System.Localization
{
    public interface ILogiszResourceManager
    {
        /// <summary>
        /// Gets a resource from the custom Logisz resource type.
        /// </summary>
        /// <param name="name">Name of the resource we are currently searching</param>
        /// <returns>Localized string</returns>
        string GetResource(string name, string type = null);
    }
}