﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Localization;
using Telerik.Sitefinity.Localization.Data;

namespace SitefinityWebApp.Logisz.Core.System.Localization.Resources
{
    /// <summary>
    /// Registers a new type of translations to our label interface
    /// </summary>
    [ObjectInfo("Logisz Resources")]
    public class LogiszResources : Resource
    {
        /// <summary>
        /// Name of the label type
        /// </summary>
        public const string ResourceName = "Logisz Resources";

        public LogiszResources() : base()
        {

        }
    }
}