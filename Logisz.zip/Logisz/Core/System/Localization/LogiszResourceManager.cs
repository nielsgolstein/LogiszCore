﻿using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using SitefinityWebApp.Logisz.Core.System.Localization.Resources;
using SitefinityWebApp.Logisz.Core.System.Logger;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using Telerik.Sitefinity.Localization;
using Telerik.Sitefinity.Localization.Data;

namespace SitefinityWebApp.Logisz.Core.System.Localization
{
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_CORE_INITIALIZE)]
    public class LogiszResourceManager : ILogiszResourceManager, ILogiszAutoInitialize
    {
        #region Attributes 

        private readonly ILogiszLogger _logger;
        private readonly ResourceManager _resourceManager;

        #endregion

        #region Constructor(s)

        private LogiszResourceManager(ILogiszLogger logger)
        {
            this._logger = logger;
            this._resourceManager = ResourceManager.GetManager();
        }

        public void AutoInitialize()
        {
            //Register the Label type.
            Res.RegisterResource<LogiszResources>();
        }

        #endregion

        /// <summary>
        /// Gets a translation
        /// </summary>
        /// <param name="name">Name of the translation</param>
        /// <param name="type">Optional type of the translation (This is the group, for example: Labels)</param>
        /// <returns>Result</returns>
        public string GetResource(string name, string type = null)
        {
            type = type ?? LogiszResources.ResourceName;
            ResourceEntry entry = _resourceManager.GetResourceOrEmpty(CultureInfo.CurrentCulture, type, name);
            return entry.Value;
        }
    }
}