﻿using Telerik.Sitefinity.Services.Events;

namespace SitefinityWebApp.Logisz.Core.Events
{
    /// <summary>
    /// Logisz event manager auto registers events.
    /// </summary>
    public interface ILogiszEventManager
    {
        /// <summary>
        /// Register a singlular sitefinity event
        /// </summary>
        /// <typeparam name="T">Event</typeparam>
        /// <param name="action">The action to be triggered</param>
        void RegisterLogiszEvent<T>(SitefinityEventHandler<T> action) where T : IEvent;
    }
}