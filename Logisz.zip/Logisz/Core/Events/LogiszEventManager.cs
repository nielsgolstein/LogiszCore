﻿using SitefinityWebApp.Logisz.Core.System.Logger;
using Telerik.Sitefinity.Services;
using Telerik.Sitefinity.Services.Events;

namespace SitefinityWebApp.Logisz.Core.Events
{
    /// <summary>
    /// Logisz event manager auto registers events.
    /// </summary>
    public sealed class LogiszEventManager : ILogiszEventManager
    {
        #region Attributes

        /// <summary>
        /// Private logger
        /// </summary>
        private readonly ILogiszLogger _logger;
        //private LogiszLogger logger { get { return LogiszLogger.GetInstance(); } }

        #endregion


        /// <summary>
        /// Auto register events
        /// </summary>
        private LogiszEventManager(ILogiszLogger logger) {
            this._logger = logger;
        }

        //public LogiszEventManager() { }


        /// <summary>
        /// Register a singlular sitefinity event
        /// </summary>
        /// <typeparam name="T">Event</typeparam>
        /// <param name="action">The action to be triggered</param>
        public void RegisterLogiszEvent<T>(SitefinityEventHandler<T> action) where T : IEvent
        {
            //Log registration
            _logger.Log("EventManager: Registered " + typeof(T).Name + " event hooked to method: " + action.Method.Name + " in " + action.Target);

            EventHub.Subscribe<T>(action);
        }
    }
}