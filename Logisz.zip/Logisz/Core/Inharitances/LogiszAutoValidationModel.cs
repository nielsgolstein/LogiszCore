﻿namespace SitefinityWebApp.Logisz.Core.Inharitances
{
    /// <summary>
    /// Auto validation model. This model can validate itsself by calling the boolean IsValid.
    /// </summary>
    public abstract class LogiszAutoValidationModel
    {
        /// <summary>
        /// This model can validate itsself by calling the boolean IsValid.
        /// </summary>
        public LogiszAutoValidationModel()
        {
            this.ErrorMessage = "No errors found.";
        }

        /// <summary>
        /// Automatically initialized bool to indicate if this model is valid
        /// </summary>
        public bool IsValid { get { return AutoValidate(); } }

        /// <summary>
        /// The error message generated after the Isvalid property getter.
        /// </summary>
        private string ErrorMessage { get; set; }

        /// <summary>
        /// Returns the error message for this validation model
        /// </summary>
        /// <returns>The error message for this validation model</returns>
        public string GetErrorMessage()
        {
            return this.ErrorMessage;
        }

        /// <summary>
        /// Updates the state to invalid and sets the errormessage of this model to the given reason of failure.
        /// </summary>
        /// <param name="reasonWhyIsInvalid">Reason for being invalid</param>
        /// <returns>False</returns>
        public bool SetModelInvalid(string reasonWhyIsInvalid)
        {
            this.ErrorMessage = reasonWhyIsInvalid;
            return false;
        }

        #region Abstract methods

        /// <summary>
        /// Self-validation
        /// </summary>
        protected abstract bool AutoValidate();

        #endregion
    }
}