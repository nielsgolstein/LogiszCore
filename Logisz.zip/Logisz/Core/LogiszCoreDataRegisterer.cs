﻿using SitefinityWebApp.Logisz.Core.Configurations;
using SitefinityWebApp.Logisz.Core.Configurations.Config;
using SitefinityWebApp.Logisz.Core.Extensions.Security;
using SitefinityWebApp.Logisz.Core.System.AutoInitializer;
using System;
using Telerik.Sitefinity.Security;

namespace SitefinityWebApp.Logisz.Core
{
    /// <summary>
    /// Registers logisz core data.
    /// </summary>
    [LogiszAutoInitializeOrder(LogiszAutoInitializeOrderValues.LOGISZ_CORE_INITIALIZE, 0)]
    public class LogiszCoreDataRegisterer : ILogiszAutoInitialize
    {
        #region Attributes

        private readonly ILogiszUserManager _logiszUserManager;
        private readonly ILogiszConfigManager _logiszConfigManager;
        private LogiszConfig config;

        #endregion

        #region Constructor

        /// <summary>
        /// Private constructor to avoid this class to be created.
        /// </summary>
        private LogiszCoreDataRegisterer(ILogiszUserManager logiszUserManager, 
            ILogiszConfigManager logiszConfigManager) {
            this._logiszUserManager = logiszUserManager;
            this._logiszConfigManager = logiszConfigManager;
            this.config = _logiszConfigManager.GetConfig();
        }

        #endregion


        /// <summary>
        /// Auto init by core
        /// </summary>
        public void AutoInitialize()
        {
            RegisterLogiszDeveloperRole();
        }

        #region Private methods

        /// <summary>
        /// Registers the logisz developer role
        /// </summary>
        private void RegisterLogiszDeveloperRole()
        {
            RoleManager roleManager = RoleManager.GetManager(SecurityConstants.ApplicationRolesProviderName);
            roleManager.Provider.SuppressSecurityChecks = true;

            //Get role name
            string roleName = config.Core.DeveloperRoleName;
            bool success = _logiszUserManager.CreateRole(roleName, roleManager);

            roleManager.Provider.SuppressSecurityChecks = false;

            if (!success)
                throw new Exception("Failed to add Logisz core developer role: " + roleName);
        }

        #endregion
    }
}