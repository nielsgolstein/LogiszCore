﻿using IdentityModel.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SitefinityWebApp.Logisz.Core.xHttp
{
    public class WebRequestHandler
    {
        private bool ForceSSL { get; set; }
        private TokenResponse RequestToken { get; set; }
        private string accessToken;
        private string refreshToken;

        public WebRequestHandler(bool forceSSL = true)
        {
            this.ForceSSL = forceSSL;
            SetOrRefreshToken();
        }

        public string DoGetRequest(string url)
        {
            //Force HTTPS
            if(ForceSSL)
                url = ForceSSLInUrl(url);

            WebRequest request = WebRequest.Create(url);
            
            // If required by the server, set the credentials.
            request.Credentials = CredentialCache.DefaultCredentials;
            
            // Get the response.
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            
            // Display the status.
            //Console.WriteLine(response.StatusDescription);
            
            // Get the stream containing content returned by the server.
            Stream dataStream = response.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);
            // Read the content.
            string responseFromServer = reader.ReadToEnd();
            
            // Cleanup the streams and the response.
            reader.Close();
            dataStream.Close();
            response.Close();

            return responseFromServer;
        }

        public bool DoPostRequest(string url, string data)
        {
            //Force HTTPS
            if (ForceSSL)
                url = ForceSSLInUrl(url);

            var request = (HttpWebRequest)WebRequest.Create(url);

            data = "{"+
              "\"PublicationDate\": \"2018-11-24T19:37:24.0113357Z\"," +
              "\"ExpirationDate\": \"2018-11-24T19:37:24.0113357Z\"," +
              "\"UrlName\": \"sample string 2\"," +
              "\"key\": \"sample string 3\"," +
              "\"value\": \"sample string 4\"" +
            "}";

            var dataBytes = Encoding.ASCII.GetBytes(data);

            request.Method = "POST";
            request.ContentType = "application/json";
            request.Headers.Add("X-SF-Service-Request: true");
            request.Headers.Add("Authorization", "Bearer " + accessToken);
            request.ContentLength = dataBytes.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(dataBytes, 0, dataBytes.Length);
            }

            var response = (HttpWebResponse)request.GetResponse();

            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            SetOrRefreshToken();

            return true;
        }

        public void SetForceSSL(bool newSSLRule)
        {
            this.ForceSSL = newSSLRule;
        }

        /// <summary>
        /// Simply forces our URL to HTTPS://
        /// </summary>
        /// <param name="url">The old, possible not SSL safe url</param>
        /// <returns>a SSL safe url.</returns>
        private string ForceSSLInUrl(string url)
        {
            url.Replace("http://", "https://");

            if (!url.Contains("https://"))
                url = string.Format("{0}{1}", "https://", url);

            return url;
        }

        /// <summary>
        /// Refreshes the accestoken and refreshtoken.
        /// </summary>
        private void SetOrRefreshToken()
        {
            if(String.IsNullOrEmpty(accessToken))
            {
                TokenResponse response = LogiszRequestTokenProvider.RequestToken();
                this.accessToken = response.AccessToken;
                this.refreshToken = response.RefreshToken;
            } else
            {
                TokenResponse response = LogiszRequestTokenProvider.RefreshToken(this.refreshToken);
                this.accessToken = response.AccessToken;
                this.refreshToken = response.RefreshToken;
            }
            
        }
    }
}